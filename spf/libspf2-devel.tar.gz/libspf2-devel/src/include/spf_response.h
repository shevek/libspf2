/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#ifndef INC_SPF_RESPONSE
#define INC_SPF_RESPONSE

typedef
enum SPF_result_enum {
	SPF_RESULT_INVALID = 0,		/* We should never return this. */
	SPF_RESULT_NEUTRAL,
	SPF_RESULT_PASS,
	SPF_RESULT_FAIL,
	SPF_RESULT_SOFTFAIL,

	SPF_RESULT_NONE,
	SPF_RESULT_TEMPERROR,
	SPF_RESULT_PERMERROR
} SPF_result_t;

/*
 * The reason that the result was returned
 *
 * This is what triggered the SPF result.  Usually, it is a mechanism in the
 * SPF record that causes the result, but if it was something else, the
 * calling program will often want to take a different action or issue
 * a different message.
 */
typedef
enum SPF_reason_enum {
	SPF_REASON_NONE			= 0
,	SPF_REASON_LOCALHOST	/* localhost always gets a free ride */
,	SPF_REASON_LOCAL_POLICY	/* local policy caused the match */
,	SPF_REASON_MECH			/* mechanism caused the match	*/
,	SPF_REASON_DEFAULT		/* ran off the end of the rec	*/
,	SPF_REASON_2MX			/* sent from a secondary MX	*/
} SPF_reason_t;


/*
 * error codes returned by various SPF functions.  (including SPF_compile()
 * and SPF_id2str(), spf_result(), etc.).
 *
 * The function SPF_strerror() will return a longer explanation of these
 * errors.
 */

typedef
enum SPF_errcode_t {
	SPF_E_SUCCESS	 = 0	/* No errors			*/
,	SPF_E_NO_MEMORY			/* Out of memory		*/
,	SPF_E_NOT_SPF			/* Could not find a valid SPF record */
,	SPF_E_SYNTAX			/* Syntax error			*/
,	SPF_E_MOD_W_PREF		/* Modifiers can not have prefixes */
,	SPF_E_INVALID_CHAR		/* Invalid character found	*/
,	SPF_E_UNKNOWN_MECH		/* Unknown mechanism found	*/
,	SPF_E_INVALID_OPT		/* Invalid option found		*/
,	SPF_E_INVALID_CIDR		/* Invalid CIDR length		*/
,	SPF_E_MISSING_OPT		/* Required option is missing	*/
,	SPF_E_INTERNAL_ERROR	/* Internal programming error	*/
,	SPF_E_INVALID_ESC		/* Invalid %-escape character	*/
,	SPF_E_INVALID_VAR		/* Invalid macro variable	*/
,	SPF_E_BIG_SUBDOM		/* Subdomain truncation depth too large */
,	SPF_E_INVALID_DELIM		/* Invalid delimiter character	*/
,	SPF_E_BIG_STRING		/* Option string too long	*/
,	SPF_E_BIG_MECH			/* Too many mechanisms		*/
,	SPF_E_BIG_MOD			/* Too many modifiers		*/
,	SPF_E_BIG_DNS			/* Mechanisms used too many DNS lookups */
,	SPF_E_INVALID_IP4		/* Invalid IPv4 address literal	*/
,	SPF_E_INVALID_IP6		/* Invalid IPv6 address literal	*/
,	SPF_E_INVALID_PREFIX	/* Invalid mechanism prefix	*/
,	SPF_E_RESULT_UNKNOWN	/* SPF result is \"unknown\"	*/
,	SPF_E_UNINIT_VAR		/* Uninitialized variable	*/
,	SPF_E_MOD_NOT_FOUND		/* Modifier not found		*/
,	SPF_E_NOT_CONFIG		/* Not configured		*/
,	SPF_E_DNS_ERROR			/* DNS lookup failure		*/
,	SPF_E_BAD_HOST_IP		/* Invalid hostname (an IP address?) */
,	SPF_E_BAD_HOST_TLD		/* Hostname has a missing or invalid TLD */
,	SPF_E_MECH_AFTER_ALL	/* Mechanisms found after the \"all:\"
								mechanism will be ignored */
} SPF_errcode_t;

typedef
struct SPF_error_struct
{
	SPF_errcode_t	 code;
	char			*message;
	char			 is_error;
} SPF_error_t;

typedef struct SPF_response_struct SPF_response_t;

#include "spf.h"
#include "spf_request.h"

struct SPF_response_struct {
	/* Structure variables */
	SPF_request_t	*spf_request;

	/* The answer itself. */
	SPF_result_t	 result;
	SPF_reason_t	 reason;
	SPF_errcode_t	 err;

	char			*received_spf;
	char			*received_spf_value;
	char			*header_comment;
	char			*smtp_comment;
	char			*explanation;

	/* The errors */
	SPF_error_t		*errors;
	unsigned short	 errors_size;		/* Allocated */
	unsigned short	 errors_length;		/* Used */
	unsigned short	 num_errors;		/* Excluding warnings */

	/* Stuff which lets us get there. */
	int				 num_dns_mech;
};


SPF_response_t	*SPF_response_new(SPF_request_t *spf_request);
void			 SPF_response_free(SPF_response_t *rp);
SPF_errcode_t	 SPF_response_error_ptr(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *text, const char *tptr,
					const char *format, ...);
SPF_errcode_t	 SPF_response_error_idx(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *text, int idx,
					const char *format, ...);
SPF_errcode_t	 SPF_response_error(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *format, ...);
SPF_errcode_t	 SPF_response_warn_ptr(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *text, const char *tptr,
					const char *format, ...);
SPF_errcode_t	 SPF_response_warn_idx(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *text, int idx,
					const char *format, ...);
SPF_errcode_t	 SPF_response_warn(SPF_response_t *rp,
					SPF_errcode_t code,
					const char *format, ...);
static inline int SPF_response_messages(SPF_response_t *rp)
	{ return rp->errors_length; }
static inline int SPF_response_errors(SPF_response_t *rp)
	{ return rp->num_errors; }
static inline int SPF_response_warnings(SPF_response_t *rp)
	{ return rp->errors_length - rp->num_errors; }
static inline SPF_error_t *SPF_response_message(SPF_response_t *rp, int idx)
	{ return &rp->errors[idx]; }


#endif
