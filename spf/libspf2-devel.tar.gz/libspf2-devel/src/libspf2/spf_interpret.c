/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 *
 *   a) The GNU Lesser General Public License as published by the Free
 *	  Software Foundation; either version 2.1, or (at your option) any
 *	  later version,
 *
 *   OR
 *
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include "spf_sys_config.h"

#ifdef STDC_HEADERS
# include <stdio.h>		/* stdin / stdout */
# include <stdlib.h>	   /* malloc / free */
#endif

#ifdef HAVE_STRING_H
# include <string.h>	   /* strstr / strdup */
#else
# ifdef HAVE_STRINGS_H
#  include <strings.h>	   /* strstr / strdup */
# endif
#endif

#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif

#include <ctype.h>

#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"
#include "spf_server.h"


#define INET_NTOP(af, src, dst, cnt) do { \
	if (inet_ntop(af, src, dst, cnt) == NULL) \
		snprintf(dst, cnt, "ip-error" ); \
			} while(0)

static int
SPF_mech_cidr( SPF_request_t *spf_request, SPF_mech_t *mech)
{
	SPF_data_t				*data;

	SPF_ASSERT_NOTNULL(mech);

	switch( mech->mech_type )
	{
	case MECH_IP4:
	case MECH_IP6:
		return mech->mech_len;
		break;

	case MECH_A:
	case MECH_MX:
		data = SPF_mech_data( mech );
		if ( data <= SPF_mech_end_data( mech )
			 && data->dc.parm_type == PARM_CIDR )
		{
			if ( spf_request->client_ver == AF_INET )
				return data->dc.ipv4;
			else if ( spf_request->client_ver == AF_INET6 )
				return data->dc.ipv6;
		}
		break;
	}

	return 0;
}



static int
SPF_match_ip4(SPF_server_t *spf_server,
			SPF_request_t *spf_request,
			SPF_mech_t *mech,
			struct in_addr ipv4 )
{
	char		src_ip4_buf[ INET_ADDRSTRLEN ];
	char		dst_ip4_buf[ INET_ADDRSTRLEN ];
	char		mask_ip4_buf[ INET_ADDRSTRLEN ];

	struct in_addr		src_ipv4;
	int				cidr, mask;


	if ( spf_request->client_ver != AF_INET )
		return FALSE;

	src_ipv4 = spf_request->ipv4;

	cidr = SPF_mech_cidr( spf_request, mech );
	if ( cidr == 0 )
		cidr = 32;
	mask = 0xffffffff << (32 - cidr);
	mask = htonl(mask);

	if (spf_server->debug) {
		INET_NTOP(AF_INET, &src_ipv4.s_addr,
						src_ip4_buf, sizeof(src_ip4_buf));
		INET_NTOP(AF_INET, &ipv4.s_addr,
						dst_ip4_buf, sizeof(dst_ip4_buf));
		INET_NTOP(AF_INET, &mask,
						mask_ip4_buf, sizeof(mask_ip4_buf));
		SPF_debugf( "ip_match:  %s == %s  (/%d %s):  %d",
				src_ip4_buf, dst_ip4_buf, cidr, mask_ip4_buf,
				(src_ipv4.s_addr & mask) == (ipv4.s_addr & mask));
	}

	return (src_ipv4.s_addr & mask) == (ipv4.s_addr & mask);
}


static int
SPF_match_ip6(SPF_server_t *spf_server,
			SPF_request_t *spf_request,
			SPF_mech_t *mech,
			struct in6_addr ipv6 )
{
	char		src_ip6_buf[ INET6_ADDRSTRLEN ];
	char		dst_ip6_buf[ INET6_ADDRSTRLEN ];

	struct in6_addr		src_ipv6;
	int				cidr, mask;
	int				i;
	int				match;

	if ( spf_request->client_ver != AF_INET6 )
		return FALSE;

	src_ipv6 = spf_request->ipv6;

	cidr = SPF_mech_cidr(spf_request, mech);
	if ( cidr == 0 )
		cidr = 128;

	match = TRUE;
	for( i = 0; i < array_elem( ipv6.s6_addr ) && match; i++ )
	{
		if ( cidr > 8 )
			mask = 0xff;
		else if ( cidr > 0 )
			mask = (0xff << (8 - cidr)) & 0xff;
		else
			break;
		cidr -= 8;

		match = (src_ipv6.s6_addr[i] & mask) == (ipv6.s6_addr[i] & mask);
	}

	if (spf_server->debug) {
		INET_NTOP(AF_INET6, &src_ipv6.s6_addr,
							src_ip6_buf, sizeof(src_ip6_buf));
		INET_NTOP(AF_INET6, &ipv6.s6_addr,
							dst_ip6_buf, sizeof(dst_ip6_buf));
		SPF_debugf( "ip_match:  %s == %s  (/%d):  %d",
				src_ip6_buf, dst_ip6_buf, cidr, match );
	}

	return match;
}

static int
SPF_match_domain(SPF_server_t *spf_server,
				const char *hostname, const char *domain)
{
	const char	*hp;
	int			 hlen;
	int			 dlen;

	if (spf_server->debug)
		SPF_debugf( "%s ?=? %s", hostname, domain );

	hlen = strlen(hostname);
	dlen = strlen(domain);

	if (dlen > hlen)
		return 1;

	if (dlen == hlen)
		return (strcasecmp(hostname, domain) == 0);

	hp = hostname + (hlen - dlen);

	if (*(hp - 1) != '.')
		return 0;

	return (strcasecmp(hp, domain) == 0);
}

#define DONE(result,reason,err) xdone(spf_response, result, reason, err)
#define DONE_TEMPERR(err) DONE(SPF_RESULT_TEMPERROR,SPF_REASON_NONE,err)
#define DONE_PERMERR(err) DONE(SPF_RESULT_PERMERROR,SPF_REASON_NONE,err)
#define DONE_MECH(result) DONE(result, SPF_REASON_MECH, SPF_E_SUCCESS)

SPF_errcode_t
xdone(SPF_response_t *spf_response,
	  SPF_result_t result,
	  SPF_reason_t reason,
	  SPF_errcode_t err)
{
	spf_response->result = result;
	spf_response->reason = reason;
	return err;
}


/*
 * Set cur_dom to either sender or or <something? [check IRC log]>
 * before calling this.
 */

SPF_errcode_t
SPF_record_interpret(SPF_server_t *spf_server,
			SPF_request_t *spf_request,
			SPF_response_t *spf_response,
			SPF_record_t *spf_record)
{
	/* Temporaries */
	int				 i, j;
	int				 m;			/* Mechanism iterator */
	SPF_mech_t		*mech;
	SPF_data_t		*data;
	SPF_data_t		*data_end;

	/* Where to insert the local policy (whitelist) */
	SPF_mech_t		*local_policy;	/* Not the local policy */
	int				 found_all;		/* A crappy temporary. */

	char			*buf = NULL;
	size_t			 buf_len = 0;
	ns_type			 fetch_ns_type;
	char			*lookup;

	SPF_dns_rr_t	*rr_a;
	SPF_dns_rr_t	*rr_aaaa;
	SPF_dns_rr_t	*rr_ptr;
	SPF_dns_rr_t	*rr_mx;

	SPF_errcode_t	 err;

	SPF_dns_config_t spfdcid;

	/* An SPF record for subrequests - replaces c_results */
	SPF_record_t	*spf_record_subr;

	char		*save_cur_dom;

	struct in_addr	addr4;
	struct in6_addr addr6;

	int				max_ptr;
	int				max_mx;

	char			 ip4_buf[ INET_ADDRSTRLEN ];
	char			 ip6_buf[ INET6_ADDRSTRLEN ];


	/*
	 * make sure we were passed valid data to work with
	 */
	SPF_ASSERT_NOTNULL(spf_server);
	SPF_ASSERT_NOTNULL(spf_request);
	SPF_ASSERT_NOTNULL(spf_record);
	SPF_ASSERT_NOTNULL(spf_response);

	if ( spf_request->client_ver != AF_INET && spf_request->client_ver != AF_INET6 )
		return DONE_PERMERR(SPF_E_NOT_CONFIG);

	if (spf_request->cur_dom == NULL)
		return DONE_PERMERR(SPF_E_NOT_CONFIG);


	/*
	 * localhost always gets a free ride
	 */

	if ( SPF_request_is_loopback( spf_request ) )
		return DONE(SPF_RESULT_PASS,SPF_REASON_LOCALHOST,SPF_E_SUCCESS);

	/*
	 * Do some start up stuff if we haven't recursed yet
	 */

	local_policy = NULL;

	if ( spf_request->use_local_policy ) {
		/*
		 * find the location for the whitelist execution
		 *
		 * Philip Gladstone says:
		 *
		 * I think that the localpolicy should only be inserted if the
		 * final mechanism is '-all', and it should be inserted after
		 * the last mechanism which is not '-'.
		 *
		 * Thus for the case of 'v=spf1 +a +mx -all', this would be
		 * interpreted as 'v=spf1 +a +mx +localpolicy -all'. Whereas
		 * 'v=spf1 -all' would remain the same (no non-'-'
		 * mechanism). 'v=spf1 +a +mx -exists:%stuff -all' would
		 * become 'v=spf1 +a +mx +localpolicy -exists:%stuff -all'.
		 */

		if ( spf_server->local_policy ) {
			mech = spf_record->mech_first;

			found_all = FALSE;
			for(m = 0; m < spf_record->num_mech; m++)
			{
				if ( mech->mech_type == MECH_ALL
					 && (mech->prefix_type == PREFIX_FAIL
						 || mech->prefix_type == PREFIX_UNKNOWN
						 || mech->prefix_type == PREFIX_SOFTFAIL
						 )
					)
					found_all = TRUE;

				if ( mech->prefix_type != PREFIX_FAIL
					 && mech->prefix_type != PREFIX_SOFTFAIL
					)
					local_policy = mech;

				mech = SPF_mech_next( mech );
			}

			if ( !found_all )
				local_policy = NULL;
		}

	}


	/*
	 * evaluate the mechanisms
	 */

#define SPF_ADD_DNS_MECH() do { spf_response->num_dns_mech++; } while(0)

#define SPF_MAYBE_SKIP_CIDR() \
	do { \
		if ( data < data_end && data->dc.parm_type == PARM_CIDR ) \
			data = SPF_data_next( data ); \
	} while(0)

#define SPF_GET_LOOKUP_DATA() \
	do {												\
		if ( data == data_end )							\
			lookup = spf_request->cur_dom;				\
		else {											\
			err = SPF_record_expand_data( spf_server,	\
							spf_request, spf_response,	\
							data, (data_end - data),	\
							&buf, &buf_len );			\
			if (err == SPF_E_NO_MEMORY)					\
				return DONE_TEMPERR(err);				\
			if (err)									\
				return DONE_PERMERR(err);				\
			lookup = buf;								\
		}												\
	} while(0)


	spfdcid = spf_server->resolver;

	mech = spf_record->mech_first;
	for( m = 0; m < spf_record->num_mech; m++ ) {

		/* This is as good a place as any. */
		if ( spf_response->num_dns_mech > spf_server->max_dns_mech
			 || spf_response->num_dns_mech > SPF_MAX_DNS_MECH )
			return DONE( SPF_RESULT_TEMPERROR, SPF_REASON_NONE, SPF_E_BIG_DNS );

		data = SPF_mech_data( mech );
		data_end = SPF_mech_end_data( mech );

		switch( mech->mech_type )
		{
		case MECH_A:
			SPF_ADD_DNS_MECH();
			SPF_MAYBE_SKIP_CIDR();
			SPF_GET_LOOKUP_DATA();

			if ( spf_request->client_ver == AF_INET )
				fetch_ns_type = ns_t_a;
			else
				fetch_ns_type = ns_t_aaaa;

			rr_a = SPF_dns_lookup( spfdcid, lookup, fetch_ns_type, TRUE );

			if ( spf_server->debug )
				SPF_debugf( "found %d A records for %s  (herrno: %d)",
						rr_a->num_rr, lookup, rr_a->herrno );

			if( rr_a->herrno == TRY_AGAIN )
				return DONE_TEMPERR(SPF_E_DNS_ERROR); /* REASON_MECH */

			for (i = 0; i < rr_a->num_rr; i++) {
				if ( rr_a->rr_type != fetch_ns_type )
					continue;

				if (spf_request->client_ver == AF_INET) {
					if (SPF_match_ip4(spf_server, spf_request, mech, rr_a->rr[i]->a))
						return DONE_MECH(mech->prefix_type);
				}
				else {
					if (SPF_match_ip6(spf_server, spf_request, mech, rr_a->rr[i]->aaaa))
						return DONE_MECH(mech->prefix_type);
				}
			}
			break;

		case MECH_MX:
			SPF_ADD_DNS_MECH();
			SPF_MAYBE_SKIP_CIDR();
			SPF_GET_LOOKUP_DATA();

			rr_mx = SPF_dns_dup_rr( SPF_dns_lookup( spfdcid, lookup,
													ns_t_mx, TRUE ) );

			if ( spf_server->debug )
				SPF_debugf( "found %d MX records for %s  (herrno: %d)",
						rr_mx->num_rr, lookup, rr_mx->herrno );

			if( rr_mx->herrno == TRY_AGAIN )
				return DONE_TEMPERR(SPF_E_DNS_ERROR);

			max_mx = rr_mx->num_rr;
			if ( max_mx > spf_server->max_dns_mx )
				max_mx = spf_server->max_dns_mx;
			if ( max_mx > SPF_MAX_DNS_MX )
				max_mx = SPF_MAX_DNS_MX;

			for( j = 0; j < max_mx; j++ )
			{
				if ( rr_mx->rr_type != ns_t_mx )
					continue;

				if ( spf_request->client_ver == AF_INET )
					fetch_ns_type = ns_t_a;
				else
					fetch_ns_type = ns_t_aaaa;

				rr_a = SPF_dns_lookup( spfdcid, rr_mx->rr[j]->mx,
									   fetch_ns_type, TRUE );

				if ( spf_server->debug )
					SPF_debugf( "%d: found %d A records for %s  (herrno: %d)",
							j, rr_a->num_rr, rr_mx->rr[j]->mx, rr_a->herrno );
				if( rr_a->herrno == TRY_AGAIN )
					return DONE_TEMPERR( SPF_E_DNS_ERROR );

				for( i = 0; i < rr_a->num_rr; i++ )
				{
					if ( rr_a->rr_type != fetch_ns_type )
						continue;

					if ( spf_request->client_ver == AF_INET )
					{
						if ( SPF_match_ip4( spf_server, spf_request, mech, rr_a->rr[i]->a ) )
						{
							SPF_dns_destroy_rr( rr_mx );

							return DONE( mech->prefix_type, SPF_REASON_MECH,
										 SPF_E_SUCCESS );
						}
					}
					else
					{
						if ( SPF_match_ip6( spf_server, spf_request, mech, rr_a->rr[i]->aaaa ) )
						{
							SPF_dns_destroy_rr( rr_mx );

							return DONE( mech->prefix_type, SPF_REASON_MECH,
										 SPF_E_SUCCESS );
						}
					}
				}
			}

			SPF_dns_destroy_rr( rr_mx );
			break;

		case MECH_PTR:
			SPF_ADD_DNS_MECH();
			SPF_GET_LOOKUP_DATA();

			if ( spf_request->client_ver == AF_INET )
			{
				rr_ptr = SPF_dns_dup_rr(SPF_dns_rlookup(spfdcid,
								spf_request->ipv4, ns_t_ptr, TRUE));

				if ( spf_server->debug ) {
					INET_NTOP(AF_INET, &spf_request->ipv4.s_addr,
										ip4_buf, sizeof(ip4_buf));
					SPF_debugf("got %d PTR records for %s (herrno: %d)",
							rr_ptr->num_rr, ip4_buf, rr_ptr->herrno);
				}

				if( rr_ptr->herrno == TRY_AGAIN )
					return DONE_TEMPERR(SPF_E_DNS_ERROR);


				max_ptr = rr_ptr->num_rr;
				if ( max_ptr > spf_server->max_dns_ptr )
					max_ptr = spf_server->max_dns_ptr;
				if ( max_ptr > SPF_MAX_DNS_PTR )
					max_ptr = SPF_MAX_DNS_PTR;

				for( i = 0; i < max_ptr; i++ ) {
					rr_a = SPF_dns_lookup( spfdcid, rr_ptr->rr[i]->ptr, ns_t_a, TRUE );

					if ( spf_server->debug )
						SPF_debugf( "%d:  found %d A records for %s  (herrno: %d)",
								i, rr_a->num_rr, rr_ptr->rr[i]->ptr, rr_a->herrno );
					if( rr_a->herrno == TRY_AGAIN )
						return DONE_TEMPERR( SPF_E_DNS_ERROR );

					for( j = 0; j < rr_a->num_rr; j++ ) {
						if ( spf_server->debug ) {
							INET_NTOP( AF_INET, &rr_a->rr[j]->a.s_addr,
											ip4_buf, sizeof(ip4_buf));
							SPF_debugf( "%d: %d:  found %s",
									i, j, ip4_buf );
						}

						if (rr_a->rr[j]->a.s_addr ==
										spf_request->ipv4.s_addr) {
							if (SPF_match_domain(spf_server,
											rr_ptr->rr[i]->ptr, lookup)) {
								SPF_dns_destroy_rr( rr_ptr );
								return DONE_MECH( mech->prefix_type );
							}
						}
					}
				}
				SPF_dns_destroy_rr( rr_ptr );
			}

			else if ( spf_request->client_ver == AF_INET6 ) {
				rr_ptr = SPF_dns_dup_rr(SPF_dns_rlookup6(spfdcid,
								spf_request->ipv6, ns_t_ptr, TRUE));

				if ( spf_server->debug ) {
					INET_NTOP( AF_INET6, &spf_request->ipv6.s6_addr,
									   ip6_buf, sizeof( ip6_buf ) );
					SPF_debugf( "found %d PTR records for %s  (herrno: %d)",
							rr_ptr->num_rr, ip6_buf, rr_ptr->herrno );
				}
				if( rr_ptr->herrno == TRY_AGAIN )
					return DONE_TEMPERR( SPF_E_DNS_ERROR );


				max_ptr = rr_ptr->num_rr;
				if ( max_ptr > spf_server->max_dns_ptr )
					max_ptr = spf_server->max_dns_ptr;
				if ( max_ptr > SPF_MAX_DNS_PTR )
					max_ptr = SPF_MAX_DNS_PTR;

				for( i = 0; i < max_ptr; i++ ) {
					rr_aaaa = SPF_dns_lookup(spfdcid, rr_ptr->rr[i]->ptr, ns_t_aaaa, TRUE);

					if ( spf_server->debug )
						SPF_debugf( "%d:  found %d AAAA records for %s  (herrno: %d)",
								i, rr_aaaa->num_rr, rr_ptr->rr[i]->ptr, rr_aaaa->herrno );
					if( rr_aaaa->herrno == TRY_AGAIN )
						return DONE_TEMPERR( SPF_E_DNS_ERROR );

					for( j = 0; j < rr_aaaa->num_rr; j++ ) {
						if ( spf_server->debug ) {
							INET_NTOP(AF_INET6, &rr_aaaa->rr[j]->aaaa.s6_addr,
											ip6_buf, sizeof(ip6_buf));
							SPF_debugf( "%d: %d:  found %s",
									i, j, ip6_buf );
						}

						if (memcmp(&rr_aaaa->rr[j]->aaaa,
								&spf_request->ipv6,
								sizeof(spf_request->ipv6)) == 0) {
							if (SPF_match_domain(spf_server,
											rr_ptr->rr[i]->ptr, lookup)) {
								SPF_dns_destroy_rr( rr_ptr );
								return DONE_MECH( mech->prefix_type );
							}
						}
					}
				}
				SPF_dns_destroy_rr( rr_ptr );
			}

			break;

		case MECH_INCLUDE:
		case MECH_REDIRECT:
			SPF_ADD_DNS_MECH();

			err = SPF_record_expand_data(spf_server,
					spf_request, spf_response,
					SPF_mech_data(mech), SPF_mech_data_len(mech),
					&buf, &buf_len );

			if ( err == SPF_E_NO_MEMORY )
				return DONE_TEMPERR( err );
			if ( err )
				return DONE_PERMERR( err );
			lookup = buf;

			/*
			 * get the (compiled) SPF record
			 */

			/* Remember to reset this. */
			save_cur_dom = spf_request->cur_dom;
			spf_request->cur_dom = lookup;
			err = SPF_server_get_record(spf_server, spf_request,
							spf_response, &spf_record_subr);

			if ( spf_server->debug > 0 )
				SPF_debugf( "include:  got SPF record:  %s",
						SPF_strerror( err ) );

			if (err != SPF_E_SUCCESS ) {
				spf_request->cur_dom = save_cur_dom;
				return DONE_TEMPERR( err );
			}

			/*
			 * find out whether this configuration passes
			 */

			err = SPF_record_interpret(spf_server,
							spf_request,
							spf_response, spf_record_subr);
			spf_request->cur_dom = save_cur_dom;

			if ( spf_server->debug > 0 )
				SPF_debugf( "include/redirect:  executed SPF record:  %s  result: %s  reason: %s",
						SPF_strerror( err ),
						SPF_strresult( spf_response->result ),
						SPF_strreason( spf_response->reason ) );
			if (mech->mech_type == MECH_REDIRECT)
				return err;
			else if (spf_response->result != SPF_RESULT_INVALID)
				return err;

			break;

		case MECH_IP4:
			memcpy(&addr4, SPF_mech_ip4_data(mech), sizeof(addr4));
			if ( SPF_match_ip4( spf_server, spf_request, mech, addr4 ) )
				return DONE_MECH( mech->prefix_type );
			break;

		case MECH_IP6:
			memcpy(&addr6, SPF_mech_ip6_data(mech), sizeof(addr6));
			if ( SPF_match_ip6( spf_server, spf_request, mech, addr6 ) )
				return DONE_MECH( mech->prefix_type );
			break;

		case MECH_EXISTS:
			SPF_ADD_DNS_MECH();

			err = SPF_record_expand_data(spf_server,
							spf_request, spf_response,
							SPF_mech_data(mech),SPF_mech_data_len(mech),
							&buf, &buf_len);
			if (err != SPF_E_SUCCESS)
				return DONE_TEMPERR( err );
			lookup = buf;

			rr_a = SPF_dns_lookup( spfdcid, lookup, ns_t_a, FALSE );

			if ( spf_server->debug )
				SPF_debugf( "found %d A records for %s  (herrno: %d)",
						rr_a->num_rr, lookup, rr_a->herrno );

			if( rr_a->herrno == TRY_AGAIN )
				return DONE_TEMPERR(SPF_E_DNS_ERROR);
			if ( rr_a->num_rr > 0 )
				return DONE_MECH(mech->prefix_type);

			break;

		case MECH_ALL:
			if (mech->prefix_type == PREFIX_UNKNOWN)
				return DONE_PERMERR(SPF_E_UNKNOWN_MECH);
			return DONE_MECH(mech->prefix_type);
			break;

		default:
			return DONE_PERMERR(SPF_E_UNKNOWN_MECH);
			break;
		}


		/*
		 * execute the local policy
		 */

		if ( mech == local_policy ) {
			err = SPF_record_interpret(spf_server,
							spf_request, spf_response,
							spf_server->local_policy);

			if ( spf_server->debug > 0 )
				SPF_debugf( "local_policy:  executed SPF record:  %s  result: %s  reason: %s",
							SPF_strerror( err ),
							SPF_strresult( spf_response->result ),
							SPF_strreason( spf_response->reason ) );

			if (spf_response->result != SPF_RESULT_INVALID)
				return err;
		}

		mech = SPF_mech_next( mech );
	}

	/* falling off the end is the same as ?all */
	return DONE( SPF_RESULT_NEUTRAL, SPF_REASON_DEFAULT, SPF_E_SUCCESS );
}
