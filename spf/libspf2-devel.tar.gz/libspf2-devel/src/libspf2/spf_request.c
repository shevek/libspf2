/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include "spf_sys_config.h"

#ifdef STDC_HEADERS
# include <stdio.h>        /* stdin / stdout */
# include <stdlib.h>       /* malloc / free */
#endif

#ifdef HAVE_STRING_H
# include <string.h>       /* strstr / strdup */
#else
# ifdef HAVE_STRINGS_H
#  include <strings.h>       /* strstr / strdup */
# endif
#endif


#include "spf.h"
#include "spf_dns.h"
#include "spf_request.h"
#include "spf_internal.h"

#define SPF_FREE(x) \
		do { if (x) free(x); (x) = NULL; } while(0)

SPF_request_t *
SPF_request_new()
{
	SPF_request_t	*sr;

	sr = (SPF_request_t *)malloc(sizeof(SPF_request_t));
	memset(sr, 0, sizeof(SPF_request_t));

	sr->client_ver = AF_UNSPEC;
	sr->ipv4.s_addr = htonl(INADDR_ANY);
	sr->ipv6 = in6addr_any;

	return sr;
}

void
SPF_request_free(SPF_request_t *sr)
{
	SPF_FREE(sr->client_dom);
	SPF_FREE(sr->env_from);
	SPF_FREE(sr->env_from_lp);
	SPF_FREE(sr->env_from_dp);
	free(sr);
}

int
SPF_request_set_ipv4(SPF_request_t *sr, struct in_addr addr)
{
	if (sr->client_dom) {
		free(sr->client_dom);
		sr->client_dom = NULL;
	}
	sr->client_ver = AF_INET;
	sr->ipv4 = addr;
	return 0;
}

int
SPF_request_set_ipv6(SPF_request_t *sr, struct in6_addr addr)
{
	if (sr->client_dom) {
		free(sr->client_dom);
		sr->client_dom = NULL;
	}
	sr->client_ver = AF_INET6;
	sr->ipv6 = addr;
	return 0;
}

int
SPF_request_set_ipv4_str(SPF_request_t *sr, const char *astr)
{
	struct in_addr	addr;
	if (astr == NULL)
		astr = "0.0.0.0";
	if (inet_pton(AF_INET, astr, &addr) <= 0)
		return -1;
	return SPF_request_set_ipv4(sr, addr);
}

int
SPF_request_set_ipv6_str(SPF_request_t *sr, const char *astr)
{
	struct in6_addr	addr;
	if (astr == NULL)
		astr = "::";
	if (inet_pton(AF_INET6, astr, &addr) <= 0)
		return -1;
	return SPF_request_set_ipv6(sr, addr);
}

int
SPF_request_set_env_from(SPF_request_t *sr, const char *from)
{
	char	*cp;
	int		 len;

	SPF_ASSERT_NOTNULL(from);
	SPF_FREE(sr->env_from);
	SPF_FREE(sr->env_from_lp);
	SPF_FREE(sr->env_from_dp);

	cp = strrchr(from, '@');
	if (cp && (cp != from)) {
		sr->env_from = strdup(from);
		sr->env_from_lp = strdup(from);	/* Too long, but simple */
		sr->env_from_lp[(cp - from)] = '\0';
		sr->env_from_dp = strdup(cp + 1);
	}
	else {
		len = sizeof("postmaster@") + strlen(from);
		sr->env_from = malloc(len + 1);	/* sizeof("") == 1? */
		sprintf(sr->env_from, "postmaster@%s", from);
		sr->env_from_lp = strdup("postmaster");
		sr->env_from_dp = strdup(from);
	}

	return 0;
}

const char *
SPF_request_get_client_dom(SPF_server_t *ss, SPF_request_t *sr)
{
	if (sr->client_dom == NULL) {
		sr->client_dom = SPF_dns_get_client_dom(ss->resolver, sr);
	}
	return sr->client_dom;
}

int
SPF_request_is_loopback( SPF_request_t *spf_request )
{
    if ( spf_request->client_ver == AF_INET )
    {
	if ( (ntohl( spf_request->ipv4.s_addr ) & IN_CLASSA_NET) == (IN_LOOPBACKNET<<24) )
	    return TRUE;
    }
    else if ( spf_request->client_ver == AF_INET6 )
    {
	if ( IN6_IS_ADDR_LOOPBACK( &spf_request->ipv6 ) )
	    return TRUE;
    }
    return FALSE;
}
