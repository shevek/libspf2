/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 *
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 *
 *   OR
 *
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include "spf_sys_config.h"


#ifdef STDC_HEADERS
# include <stdio.h>        /* stdin / stdout */
# include <stdlib.h>       /* malloc / free */
# include <ctype.h>        /* isupper / tolower */
#endif

#ifdef HAVE_INTTYPES_H
#include <inttypes.h>
#endif

#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif

#ifdef HAVE_STRING_H
# include <string.h>       /* strstr / strdup */
#else
# ifdef HAVE_STRINGS_H
#  include <strings.h>       /* strstr / strdup */
# endif
#endif



#include "spf.h"
#include "spf_response.h"
#include "spf_record.h"
#include "spf_server.h"
#include "spf_dns.h"
#include "spf_dns_resolv.h"
#include "spf_dns_cache.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"


SPF_server_t *
SPF_server_new(SPF_server_dnstype_t dnstype, int debug)
{
	SPF_response_t		*spf_response;
	SPF_dns_config_t	 dc_r;
	SPF_dns_config_t	 dc_c;
	SPF_server_t		*sp;
	SPF_errcode_t		 err;

	sp = (SPF_server_t *)malloc(sizeof(SPF_server_t));

	sp->max_dns_mech = SPF_MAX_DNS_MECH;
	sp->max_dns_ptr = SPF_MAX_DNS_PTR;
	sp->max_dns_mx = SPF_MAX_DNS_MX;
	sp->debug = debug;

	switch (dnstype) {
		case SPF_DNS_RESOLV:
			dc_r = SPF_dns_create_config_resolv(0, debug);
			if (dc_r == 0)
				SPF_error("Failed to create DNS resolver");
			sp->resolver = dc_r;
			break;

		case SPF_DNS_CACHE:
			dc_r = SPF_dns_create_config_resolv(0, debug);
			if (dc_r == 0)
				SPF_error("Failed to create DNS resolver");
			dc_c = SPF_dns_create_config_cache(dc_r, 8, debug);
			if (dc_c == 0)
				SPF_error("Failed to create DNS cache");
			sp->resolver = dc_c;
			break;

		default:
			SPF_errorf("Unknown DNS type %d", dnstype);
	}

	spf_response = NULL;
	err = SPF_server_set_explanation(sp, SPF_DEFAULT_EXP,&spf_response);
	if (SPF_response_messages(spf_response) > 0)
		SPF_error("Response errors compiling default explanation");
	if (err != SPF_E_SUCCESS)
		SPF_errorf("Error code %d compiling default explanation", err);
	if (spf_response)
		SPF_response_free(spf_response);

	return sp;
}

void
SPF_server_free(SPF_server_t *sp)
{
	/* XXX We have to destroy the underlying DNS layer as well. */
	SPF_dns_destroy_config(sp->resolver);
	if (sp->local_policy)
		SPF_record_free(sp->local_policy);
	if (sp->explanation)
		SPF_macro_free(sp->explanation);
	/* XXX TODO: Free other parts of the structure. */
	free(sp);
}

SPF_errcode_t
SPF_server_set_explanation(SPF_server_t *sp, const char *exp,
				SPF_response_t **spf_responsep)
{
	SPF_macro_t		*spf_macro = NULL;
	SPF_errcode_t	 err;

	SPF_ASSERT_NOTNULL(exp);

	/* This is a hackish way to get the errors. */
	if (! *spf_responsep)
		*spf_responsep = SPF_response_new(NULL);

	err = SPF_record_compile_macro(sp, *spf_responsep, &spf_macro, exp);
	if (err == SPF_E_SUCCESS) {
		if (sp->explanation)
			SPF_macro_free(sp->explanation);
		sp->explanation = spf_macro;
	}
	else {
		SPF_response_error(*spf_responsep, err,
				"Failed to compile explanation '%s'", exp);
		if (spf_macro)
			SPF_macro_free(spf_macro);
	}

	return err;
}

SPF_errcode_t
SPF_server_set_localpolicy(SPF_server_t *sp, const char *policy,
				SPF_response_t **spf_responsep)
{
	SPF_record_t	*spf_record = NULL;
	SPF_errcode_t	 err;

	SPF_ASSERT_NOTNULL(policy);

	/* This is a hackish way to get the errors. */
	if (! *spf_responsep)
		*spf_responsep = SPF_response_new(NULL);

	err = SPF_record_compile(sp, *spf_responsep, &spf_record, policy);
	if (err == SPF_E_SUCCESS) {
		if (sp->local_policy)
			SPF_record_free(sp->local_policy);
		sp->local_policy = spf_record;
	}
	else {
		SPF_response_error(*spf_responsep, err,
				"Failed to compile local policy '%s'", policy);
		if (spf_record)
			SPF_record_free(spf_record);
	}

	return err;
}

SPF_errcode_t
SPF_server_get_record(SPF_server_t *spf_server,
				SPF_request_t *spf_request,
				SPF_response_t *spf_response,
				SPF_record_t **spf_recordp)
{
	SPF_dns_iconfig_t		*spfdic;
	SPF_dns_rr_t			*rr_txt;
	SPF_errcode_t			 err;
	const char				*domain;
	int						 num_found;
	int						 i;

	*spf_recordp = NULL;

	SPF_ASSERT_NOTNULL(spf_server);
	SPF_ASSERT_NOTNULL(spf_request);
	SPF_ASSERT_NOTNULL(spf_server->resolver);
	SPF_ASSERT_NOTNULL(spf_recordp);

	domain = spf_request->cur_dom;
	SPF_ASSERT_NOTNULL(domain);

	spfdic = SPF_dcid2spfdic( spf_server->resolver );

	if ( spfdic->get_spf )
		return spfdic->get_spf(spf_server, spf_request,
						spf_response, spf_recordp);

	rr_txt = SPF_dns_lookup(spf_server->resolver, domain, ns_t_txt, TRUE);

	switch( rr_txt->herrno ) {
		case HOST_NOT_FOUND:
			return SPF_response_error(spf_response, SPF_E_NOT_SPF,
					"Host '%s' not found.", domain);
			break;

		case NO_DATA:
			return SPF_response_error(spf_response, SPF_E_NOT_SPF,
					"No DNS data for '%s'.", domain);
			break;

		case TRY_AGAIN:
			return SPF_response_error(spf_response, SPF_E_DNS_ERROR,
					"Temporary DNS failure for '%s'.", domain);
			break;

		case NETDB_SUCCESS:
			break;

		default:
			return SPF_response_error(spf_response, SPF_E_DNS_ERROR,
					"Unknown DNS failure for '%s': %d.",
					domain, rr_txt->herrno);
			break;
	}

	if ( rr_txt->num_rr == 0 )
		return SPF_response_error(spf_response, SPF_E_NOT_SPF,
				"No TXT records returned from DNS lookup for '%s'",
				domain);

	/* check for multiple SPF records */
	num_found = 0;
	for( i = 0; i < rr_txt->num_rr; i++ ) {
		if ( strncmp( rr_txt->rr[i]->txt,
					  SPF_VER_STR " ", sizeof( SPF_VER_STR " " ) - 1) == 0 )
		{
			if ( spf_server->debug > 0 )
				SPF_debugf( "found SPF record: %s", rr_txt->rr[i]->txt );

			num_found++;
		}
	}

	if ( num_found == 0 )
		return SPF_response_error(spf_response, SPF_E_NOT_SPF,
				"No SPF records for '%s'", domain);
	if ( num_found > 1 )
		return SPF_response_error(spf_response, SPF_E_RESULT_UNKNOWN,
				"Multiple SPF records for '%s'", domain);

	/* try to compile the SPF record */
	for( i = 0; i < rr_txt->num_rr; i++ ) {
		err = SPF_record_compile(spf_server,
						spf_response, spf_recordp,
						rr_txt->rr[i]->txt );
		/* FIXME:  support multiple versions */
		if ( err == SPF_E_SUCCESS )
			break;
	}

	return SPF_response_error(spf_response, SPF_E_NOT_SPF,
			"Failed to compile any SPF record for '%s'", domain);
}

static SPF_errcode_t
SPF_server_set_smtp_comment(SPF_server_t *spf_server,
				SPF_request_t *spf_request,
				SPF_response_t *spf_response,
				SPF_record_t *spf_record)
{
	SPF_errcode_t	 err;
	char			*buf;
	int				 buflen;
	int				 len;

	/* smtp_comment = exp= + <why string> */
	switch (spf_response->result) {
		case SPF_RESULT_FAIL:
		case SPF_RESULT_SOFTFAIL:
		case SPF_RESULT_NONE:
			buflen = SPF_SMTP_COMMENT_SIZE + 1;
			buf = malloc(buflen);
			memset(buf, '\0', buflen);

			err = SPF_request_get_exp(spf_server, spf_request,
							spf_response, spf_record, &buf, &buflen);

			/* buf should now be malloc'd */
			if (buf == NULL || buf[0] == '\0')
				break;
			/* Someone might have realloc'd us smaller? */
			if (buflen < SPF_SMTP_COMMENT_SIZE + 1)
				buf = realloc(buf, SPF_SMTP_COMMENT_SIZE + 1);

			len = strlen(buf);
			if (len < SPF_SMTP_COMMENT_SIZE)
				snprintf(&buf[len], SPF_SMTP_COMMENT_SIZE - len - 1,
						" : Reason: %s",
						SPF_strreason(spf_response->reason));
			buf[SPF_SMTP_COMMENT_SIZE] = '\0';

			spf_response->smtp_comment = buf;
			break;
		case SPF_RESULT_INVALID:
		case SPF_RESULT_NEUTRAL:
		case SPF_RESULT_PASS:
		case SPF_RESULT_TEMPERROR:
		case SPF_RESULT_PERMERROR:
		default:
			if (spf_response->smtp_comment)
				free(spf_response->smtp_comment);
			spf_response->smtp_comment = NULL;
			err = SPF_E_SUCCESS;
			break;
	}

	return err;
}

static SPF_errcode_t
SPF_server_set_header_comment(SPF_server_t *spf_server,
				SPF_request_t *spf_request,
				SPF_response_t *spf_response,
				SPF_record_t *spf_record)
{
	char			*spf_source;

	size_t			 len;

	char			 ip4_buf[ INET_ADDRSTRLEN ];
	char			 ip6_buf[ INET6_ADDRSTRLEN ];
	const char		*ip;

	char			*buf;
	char			*sender_dom;
	char			*p, *p_end;


	/* Is this cur_dom? */
	sender_dom = spf_request->env_from_dp;
	if (sender_dom == NULL)
		sender_dom = spf_request->helo_dom;

	if ( spf_response->reason == SPF_REASON_LOCAL_POLICY ) {
		spf_source = strdup( "local policy" );
	}
	else if ( spf_response->reason == SPF_REASON_2MX ) {
		if ( spf_request->rcpt_to_dom == NULL  || spf_request->rcpt_to_dom[0] == '\0' )
			SPF_error( "RCPT TO domain is NULL" );

		spf_source = strdup( spf_request->rcpt_to_dom );
	}
	else if ( sender_dom == NULL ) {
		spf_source = strdup( "unknown domain" );
	}
	else {
		len = strlen( sender_dom ) + sizeof( "domain of " );
		spf_source = malloc( len );
		if ( spf_source )
			snprintf( spf_source, len, "domain of %s", sender_dom );
	}

	if ( spf_source == NULL )
		return SPF_E_INTERNAL_ERROR;

	ip = NULL;
	if ( spf_request->client_ver == AF_INET ) {
		ip = inet_ntop( AF_INET, &spf_request->ipv4,
						ip4_buf, sizeof( ip4_buf ) );
	}
	else if (spf_request->client_ver == AF_INET6 ) {
		ip = inet_ntop( AF_INET6, &spf_request->ipv6,
						ip6_buf, sizeof( ip6_buf ) );
	}
	if ( ip == NULL )
		ip = "(unknown ip address)";

	len = strlen( spf_request->rec_dom ) + strlen( spf_source ) + strlen( ip ) + 80;
	buf = malloc( len );
	if ( buf == NULL ) {
		free( spf_source );
		return SPF_E_INTERNAL_ERROR;
	}

	p = buf;
	p_end = p + len;

	/* create the stock header comment */
	p += snprintf( p, p_end - p, "%s: ",  spf_request->rec_dom );

	switch(spf_response->result)
	{
	case SPF_RESULT_PASS:
		if ( spf_response->reason == SPF_REASON_LOCALHOST )
			snprintf( p, p_end - p, "localhost is always allowed." );
		else if ( spf_response->reason == SPF_REASON_2MX )
			snprintf( p, p_end - p, "message received from %s which is an MX secondary for %s.",
					  ip, spf_source );
		else
			snprintf( p, p_end - p, "%s designates %s as permitted sender",
					  spf_source, ip );
		break;

	case SPF_RESULT_FAIL:
		snprintf( p, p_end - p, "%s does not designate %s as permitted sender",
				  spf_source, ip );
		break;

	case SPF_RESULT_SOFTFAIL:
		snprintf( p, p_end - p, "transitioning %s does not designate %s as permitted sender",
				  spf_source, ip );
		break;

	case SPF_RESULT_PERMERROR:
		snprintf( p, p_end - p, "error in processing during lookup of %s: %s",
					  spf_source, SPF_strerror( spf_response->err ) );
		break;

	case SPF_RESULT_NEUTRAL:
	case SPF_RESULT_NONE:
		snprintf( p, p_end - p, "%s is neither permitted nor denied by %s",
				  ip, spf_source );
		break;

	case SPF_RESULT_TEMPERROR:
		snprintf( p, p_end - p, "encountered temporary error during SPF processing of %s",
				  spf_source );
		break;


	default:
		snprintf( p, p_end - p, "error: unknown SPF result %d encountered while checking %s for %s",
				  spf_response->result, ip, spf_source );
		break;
	}

	if( spf_source )
		free( spf_source );

	spf_response->header_comment = buf;

	return SPF_E_SUCCESS;
}

static SPF_errcode_t
SPF_server_set_received_spf(SPF_server_t *spf_server,
				SPF_request_t *spf_request,
				SPF_response_t *spf_response,
				SPF_record_t *spf_record)
{
	char		 ip4_buf[ INET_ADDRSTRLEN ];
	char		 ip6_buf[ INET6_ADDRSTRLEN ];
	const char	*ip;

	char		*buf;
	size_t		 buflen = SPF_RECEIVED_SPF_SIZE;
	char		*buf_value;
	
	char		*p, *p_end;

	buf = malloc( buflen );
	if ( buf == NULL )
		return SPF_E_INTERNAL_ERROR;
	
	p = buf;
	p_end = p + buflen;

	/* create the stock Received-SPF: header */

	p += snprintf( p, p_end - p, "Received-SPF: ");
	buf_value = p;

	spf_response->received_spf = buf;
	spf_response->received_spf_value = buf_value;

	p += snprintf( p, p_end - p, "%s (%s)",
				   SPF_strresult( spf_response->result ),
				   spf_response->header_comment );
	if ( p_end - p <= 0 ) return SPF_E_SUCCESS;

	
	
	/* add in the optional ip address keyword */
	ip = NULL;
	if ( spf_request->client_ver == AF_INET ) {
		ip = inet_ntop( AF_INET, &spf_request->ipv4,
						ip4_buf, sizeof( ip4_buf ) );
	}
	else if (spf_request->client_ver == AF_INET6 ) {
		ip = inet_ntop( AF_INET6, &spf_request->ipv6,
						ip6_buf, sizeof( ip6_buf ) );
	}

	if ( ip != NULL ) {
		p += snprintf( p, p_end - p, " client-ip=%s;", ip );
		if ( p_end - p <= 0 ) return SPF_E_SUCCESS;
	}
	

	/* add in the optional envelope-from keyword */
	if ( spf_request->env_from != NULL ) {
		p += snprintf( p, p_end - p, " envelope-from=%s;", spf_request->env_from );
		if ( p_end - p <= 0 ) return SPF_E_SUCCESS;
	}
	

	/* add in the optional helo domain keyword */
	if ( spf_request->helo_dom != NULL ) {
		p += snprintf( p, p_end - p, " helo=%s;", spf_request->helo_dom );
		if ( p_end - p <= 0 ) return SPF_E_SUCCESS;
	}
	

	/* FIXME: Add in full compiler errors. */
#if 0
	/* add in the optional compiler error keyword */
	if ( output.err_msg != NULL ) {
		p += snprintf( p, p_end - p, " problem=%s;", output.err_msg );
		if ( p_end - p <= 0 ) return SPF_E_SUCCESS;
	}
	else if ( c_results.err_msg != NULL ) {
		p += snprintf( p, p_end - p, " problem=%s;", c_results.err_msg );
		if ( p_end - p <= 0 ) return SPF_E_SUCCESS;
	}
#endif

	/* FIXME  should the explanation string be included in the header? */

	/* FIXME  should the header be reformated to include line breaks? */

	return SPF_E_SUCCESS;
}

/* The big entry point */
SPF_errcode_t
SPF_server_query(SPF_server_t *spf_server,
				SPF_request_t *spf_request,
				SPF_response_t **spf_responsep)
{
	SPF_errcode_t	 err;
	SPF_record_t	*spf_record;

	spf_request->spf_server = spf_server;

	*spf_responsep = SPF_response_new(spf_request);
	if (spf_request->use_helo)
		spf_request->cur_dom = spf_request->helo_dom;
	else
		spf_request->cur_dom = spf_request->env_from_dp;
	err = SPF_server_get_record(spf_server, spf_request,
					*spf_responsep, &spf_record);
	if (err != SPF_E_SUCCESS)
		return err;
	err = SPF_record_interpret(spf_server, spf_request,
								*spf_responsep, spf_record);
	(*spf_responsep)->err = err;

	SPF_server_set_smtp_comment(spf_server, spf_request,
					*spf_responsep, spf_record);
	SPF_server_set_header_comment(spf_server, spf_request,
					*spf_responsep, spf_record);
	SPF_server_set_received_spf(spf_server, spf_request,
					*spf_responsep, spf_record);

	/* Modify by reference, not totally pretty. */
	SPF_sanitize(spf_server, (*spf_responsep)->smtp_comment);
	SPF_sanitize(spf_server, (*spf_responsep)->header_comment);
	SPF_sanitize(spf_server, (*spf_responsep)->received_spf);

	return err;
}
