/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF_DNS_NULL
#define INC_SPF_DNS_NULL

SPF_dns_config_t SPF_dns_create_config_null();
void SPF_dns_reset_config_null( SPF_dns_config_t spfdcid );
void SPF_dns_destroy_config_null( SPF_dns_config_t spfdcid );


#endif
