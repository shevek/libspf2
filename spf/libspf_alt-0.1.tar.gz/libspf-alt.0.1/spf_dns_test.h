/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF_DNS_TEST
#define INC_SPF_DNS_TEST

SPF_dns_config_t SPF_dns_create_config_test( SPF_dns_config_t layer_below );
void SPF_dns_reset_config_test( SPF_dns_config_t spfdc );
void SPF_dns_destroy_config_test( SPF_dns_config_t spfdc );


#endif
