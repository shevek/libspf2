/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */


#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_dns_null.h"
#include "spf_dns_resolv.h"
#include "spf_dns_test.h"
#include "spf_dns_cache.h"



#define TRUE 1
#define FALSE 0


void usage()
{
    fprintf( stderr, "Usage:\n" );
    fprintf( stderr, "\n" );
    fprintf( stderr, "spfquery [-v] [-f <file>|spf data options]\n" );

    fprintf( stderr, "\n" );

    fprintf( stderr, "spfquery -ipv4=<IP Address> -sender=<email address> -helo=<domain>\n" );
    fprintf( stderr, "spfquery -f test_data\n" );
    fprintf( stderr, "echo \"127.0.0.1 myname@mydomain.com helohost.com\" | spfquery -f -\n" );
}


int main( int argc, char *argv[] )
{
    int c;
    int	res = 0;

    char *opt_file = NULL;

    char *opt_ipv4 = NULL;
    char *opt_sender = NULL;
    char *opt_helo = NULL;
    char *opt_rcpt_to = NULL;

    char *opt_local = NULL;
    int   opt_trusted = 0;
    char *opt_guess = NULL;
    char *opt_exp = NULL;
    char *opt_max_lookup = NULL;
    char *opt_sanitize = NULL;
    char *opt_name = "spfquery";
    int   opt_debug = 0;
    char *opt_dns = "resolv,cache";


    char in_line[4096];
    char *p, *p_end;
    int	 i;

    SPF_id_t		spfid = NULL;
    SPF_config_t	spfcid = NULL;
    SPF_dns_config_t	spfdcid_null = NULL;
    SPF_dns_config_t	spfdcid_resolv = NULL;
    SPF_dns_config_t	spfdcid_test = NULL;
    SPF_dns_config_t	spfdcid_cache = NULL;
    SPF_dns_config_t	spfdcid = NULL;
#define MAX_DNS_LAYERS 10
    SPF_dns_config_t	spfdcid_opt[MAX_DNS_LAYERS] = { NULL };
    SPF_dns_config_t	prev_dns = NULL;
    SPF_output_t	spf_output;
    SPF_c_results_t	local_policy;
    SPF_c_results_t	best_guess;
    SPF_err_t		err;
    
    FILE *fin;

    /*
     * check the arguments
     */

    while (1)
    {
	int option_index = 0;

	static struct option long_options[] = {
	    {"file", 1, 0, 'f'},

	    {"ipv4", 1, 0, 'i'},
	    {"sender", 1, 0, 's'},
	    {"helo", 1, 0, 'h'},
	    {"rcpt-to", 1, 0, 'r'},

	    {"local", 1, 0, 'l'},
	    {"trusted", 1, 0, 't'},
	    {"guess", 1, 0, 'g'},
	    {"default-explanation", 1, 0, 'e'},
	    {"max-lookup", 1, 0, 'm'},
	    {"sanitize", 1, 0, 'c'},
	    {"name", 1, 0, 'n'},

	    {"dns", 1, 0, 'D'},
	    {"debug", 2, 0, 'd'},
	    {"version", 0, 0, '?'},
	    {"help", 0, 0, '?'},

	    {0, 0, 0, 0}
	};

	c = getopt_long_only (argc, argv, "f:i:s:h:r:lt::gemcnd::D:",
			      long_options, &option_index);

	if (c == -1)
	    break;

	switch (c)
	{
	case 'f':
	    opt_file = optarg;
	    break;


	case 'i':
	    opt_ipv4 = optarg;
	    break;

	case 's':
	    opt_sender = optarg;
	    break;

	case 'h':
	    opt_helo = optarg;
	    break;

	case 'r':
	    opt_rcpt_to = optarg;
	    fprintf( stderr, "Unimplemented option: -rcpt-to\n" );
	    break;


	case 'l':
	    opt_local = optarg;
	    break;

	case 't':
	    if (optarg == NULL)
		opt_trusted = 1;
	    else
		opt_trusted = atoi( optarg );
	    break;

	case 'g':
	    opt_guess = optarg;
	    break;

	case 'e':
	    opt_exp = optarg;
	    break;

	case 'm':
	    opt_max_lookup = optarg;
	    break;

	case 'c':			/* "clean"			*/
	    opt_sanitize = optarg;
	    break;

	case 'n':			/* name of host doing SPF checking */
	    opt_name = optarg;
	    break;

	case 'D':			/* DNS layers to use              */
	    opt_dns = optarg;
	    break;


	case 0:
	case '?':
	    usage();
	    res = 255;
	    goto error;
	    break;

	case 'd':
	    if (optarg == NULL)
		opt_debug = 1;
	    else
		opt_debug = atoi( optarg );
	    break;

	default:
	    fprintf( stderr, "Error: getopt returned character code 0%o ??\n", c);
	}
    }

    if (optind != argc)
    {
	usage();
	res = 255;
	goto error;
    }

    /*
     * set up the SPF configuration
     */

    spfcid = SPF_create_config();
    if ( spfcid == NULL )
    {
	fprintf( stderr, "SPF_create_config failed.\n" );
	res = 255;
	goto error;
    }

    SPF_set_debug( spfcid, 1 );		/* flush err msgs from init	*/
    SPF_set_debug( spfcid, opt_debug );
    if ( opt_name )
	SPF_set_rec_dom( spfcid, opt_name );
    if( opt_exp )
	SPF_set_exp( spfcid, opt_exp );
    if ( opt_sanitize )
	SPF_set_sanitize( spfcid, atoi( opt_sanitize ) );
    if ( opt_max_lookup )
	SPF_set_max_dns_lookup( spfcid, atoi( opt_max_lookup ) );
    
    SPF_init_c_results( &local_policy );
    err = SPF_compile_local_policy( spfcid, opt_local, opt_trusted,
				    &local_policy );
    if ( err )
    {
	fprintf( stderr, "Error compiling local policy:\n%s\n",
		 local_policy.err_msg );
	res = 255;
	goto error;
    }
    SPF_set_local_policy( spfcid, local_policy );

    SPF_init_c_results( &best_guess );
    if ( opt_guess )
    {
	err = SPF_compile_local_policy( spfcid, opt_guess,
					opt_trusted, &best_guess );
	if ( err )
	{
	    fprintf( stderr, "Error compiling best guess mechanisms:\n%s",
		     best_guess.err_msg );
	    res = 255;
	    goto error;
	}
    }


    /*
     * set up dns layers to use
     */
    p = opt_dns;
    prev_dns = NULL;
    memset( spfdcid_opt, 0, sizeof( spfdcid ) );
    for( i = 0; i < MAX_DNS_LAYERS; i++ )
    {
	p_end = p + strcspn( p, "," );
	if ( p_end - p == sizeof( "null" ) - 1
	     && strncmp( "null", p, p_end - p ) == 0 )
	{
	    spfdcid_opt[i] = SPF_dns_create_config_null( prev_dns, opt_debug );
	}
	else if ( p_end - p == sizeof( "resolv" ) - 1
		  && strncmp( "resolv", p, p_end - p ) == 0 )
	{
	    spfdcid_opt[i] = SPF_dns_create_config_resolv( prev_dns, opt_debug );
	}
	else if ( p_end - p == sizeof( "test" ) - 1
		  && strncmp( "test", p, p_end - p ) == 0 )
	{

	    spfdcid_opt[i] = SPF_dns_create_config_test( prev_dns );
	}
	else if ( p_end - p == sizeof( "cache" ) - 1
		  && strncmp( "cache", p, p_end - p ) == 0 )
	{
	    spfdcid_opt[i] = SPF_dns_create_config_cache( prev_dns, 8 );
	}

	if ( spfdcid_opt[i] == NULL )
	{
	    fprintf( stderr, "Could not create DNS layer: %.*s\n",
		     p_end - p, p );
	    res = 255;
	    goto error;
	}

	prev_dns = spfdcid_opt[i];
	if ( *p_end == '\0' )
	    break;
	p = p_end + 1;
    }
    
    spfdcid = spfdcid_opt[i];
	

    /*
     * process the SPF request
     */

    if (opt_ipv4 == NULL || (opt_sender == NULL && opt_helo == NULL) )
    {
	if (opt_file == NULL ||
	    opt_ipv4 || opt_sender || opt_helo)
	{
	    usage();
	    res = 255;
	    goto error;
	}

	/*
	 * the requests are on STDIN
	 */

	if (strcmp( opt_file, "-" ) == 0) 
	    fin = stdin;
	else
	    fin = fopen( opt_file, "r" );

	if (!fin) 
	{
	    fprintf( stderr, "Could not open: %s\n", opt_file );
	    res = 255;
	    goto error;
	}

	while ( TRUE )
	{
	    if ( fgets( in_line, sizeof( in_line ), fin ) == NULL )
		break;

	    p = strchr( in_line, '\n' );

	    if ( p )
		*p = '\0';

	    p = in_line;

	    while( (opt_ipv4 = strsep( &p, " \t\n" ))
		   && *opt_ipv4 == '\0' )
		;

	    if (opt_ipv4 == NULL  ||  *opt_ipv4 == '#')
		continue;

	    while( (opt_sender = strsep( &p, " \t\n" ))
		   && *opt_sender == '\0' )
		;

	    while( (opt_helo = strsep( &p, " \t\n" ))
		   && *opt_helo == '\0' )
		;

	    if ( SPF_set_ipv4_str( spfcid, opt_ipv4 ) )
	    {
		printf( "Invalid IP address.\n" );
		res = 255;
		goto error;
	    }
	
	    if ( SPF_set_helo_dom( spfcid, opt_helo ) )
	    {
		printf( "Invalid HELO domain.\n" );
		res = 255;
		goto error;
	    }
	
	    if ( SPF_set_env_from( spfcid, opt_sender ) )
	    {
		printf( "Invalid envelope from address.\n" );
		res = 255;
		goto error;
	    }
	

	    spf_output = SPF_result( spfcid, spfdcid, NULL );

	    if ( opt_debug > 0 )
	    {
		printf ( "result = %s (%d)\n",
			 SPF_strresult( spf_output.result ), spf_output.result );
		printf ( "err = %s (%d)\n",
			 SPF_strerror( spf_output.err ), spf_output.err );
		printf ( "err_msg = %s\n", spf_output.err_msg );
		printf ( "smtp_comment = %s\n", spf_output.smtp_comment );
		printf ( "header_comment = %s\n", spf_output.header_comment );
		printf ( "received_spf = %s\n", spf_output.received_spf );
	    }

	    printf( "%s\n%s\n%s\n%s\n",
		    SPF_strresult( spf_output.result ),
		    spf_output.smtp_comment ? spf_output.smtp_comment : "",
		    spf_output.header_comment ? spf_output.header_comment : "",
		    spf_output.received_spf ? spf_output.received_spf : "" );

	    if ( opt_guess )
	    {
		SPF_free_output( &spf_output );

		printf( "\nBest guess:\n" );
	    
		spf_output = SPF_result_id( spfcid, best_guess.spfid, spfdcid );

		if ( opt_debug > 0 )
		{
		    printf ( "result = %s (%d)\n",
			     SPF_strresult( spf_output.result ), spf_output.result );
		    printf ( "err = %s (%d)\n",
			     SPF_strerror( spf_output.err ), spf_output.err );
		    printf ( "err_msg = %s\n", spf_output.err_msg );
		    printf ( "smtp_comment = %s\n", spf_output.smtp_comment );
		    printf ( "header_comment = %s\n", spf_output.header_comment );
		    printf ( "received_spf = %s\n", spf_output.received_spf );
		}

		printf( "%s\n%s\n%s\n%s\n",
			SPF_strresult( spf_output.result ),
			spf_output.smtp_comment ? spf_output.smtp_comment : "",
			spf_output.header_comment ? spf_output.header_comment : "",
			spf_output.received_spf ? spf_output.received_spf : "" );
	    }
	
	    res = spf_output.result;

	    SPF_free_output( &spf_output );

	}
    }
    else
    {
	/*
	 * The request was given on the command line
	 */

	if (opt_file)
	{
	    usage();
	    res = 255;
	    goto error;
	}


	if ( SPF_set_ipv4_str( spfcid, opt_ipv4 ) )
	{
	    printf( "Invalid IP address.\n" );
	    res = 255;
	    goto error;
	}
	
	if ( SPF_set_helo_dom( spfcid, opt_helo ) )
	{
	    printf( "Invalid HELO domain.\n" );
	    res = 255;
	    goto error;
	}
	
	if ( SPF_set_env_from( spfcid, opt_sender ) )
	{
	    printf( "Invalid envelope from address.\n" );
	    res = 255;
	    goto error;
	}
	

	spf_output = SPF_result( spfcid, spfdcid, NULL );

	if ( opt_debug > 0 )
	{
	    printf ( "result = %s (%d)\n",
		     SPF_strresult( spf_output.result ), spf_output.result );
	    printf ( "err = %s (%d)\n",
		     SPF_strerror( spf_output.err ), spf_output.err );
	    printf ( "err_msg = %s\n", spf_output.err_msg );
	    printf ( "smtp_comment = %s\n", spf_output.smtp_comment );
	    printf ( "header_comment = %s\n", spf_output.header_comment );
	    printf ( "received_spf = %s\n", spf_output.received_spf );
	}

	printf( "%s\n%s\n%s\n%s\n",
		SPF_strresult( spf_output.result ),
		spf_output.smtp_comment ? spf_output.smtp_comment : "",
		spf_output.header_comment ? spf_output.header_comment : "",
		spf_output.received_spf ? spf_output.received_spf : "" );

	if ( opt_guess )
	{
	    SPF_free_output( &spf_output );

	    printf( "\nBest guess:\n" );
	    
	    spf_output = SPF_result_id( spfcid, best_guess.spfid, spfdcid );

	    if ( opt_debug > 0 )
	    {
		printf ( "result = %s (%d)\n",
			 SPF_strresult( spf_output.result ), spf_output.result );
		printf ( "err = %s (%d)\n",
			 SPF_strerror( spf_output.err ), spf_output.err );
		printf ( "err_msg = %s\n", spf_output.err_msg );
		printf ( "smtp_comment = %s\n", spf_output.smtp_comment );
		printf ( "header_comment = %s\n", spf_output.header_comment );
		printf ( "received_spf = %s\n", spf_output.received_spf );
	    }

	    printf( "%s\n%s\n%s\n%s\n",
		    SPF_strresult( spf_output.result ),
		    spf_output.smtp_comment ? spf_output.smtp_comment : "",
		    spf_output.header_comment ? spf_output.header_comment : "",
		    spf_output.received_spf ? spf_output.received_spf : "" );
	}
	
	res = spf_output.result;

	SPF_free_output( &spf_output );
    }

  error:
    if ( spfid ) SPF_destroy_id( spfid );
    if ( spfdcid_null ) SPF_dns_destroy_config_null( spfdcid_null );
    if ( spfdcid_resolv ) SPF_dns_destroy_config_resolv( spfdcid_resolv );
    if ( spfdcid_test ) SPF_dns_destroy_config_test( spfdcid_test );
    if ( spfdcid_cache ) SPF_dns_destroy_config_cache( spfdcid_cache );
    for( i = MAX_DNS_LAYERS-1; i >= 0; i-- )
    {
	if ( spfdcid_opt[i] != NULL )
	    SPF_dns_destroy_config( spfdcid_opt[i] );
    }
    if ( spfcid ) SPF_destroy_config( spfcid );
    SPF_free_c_results( &local_policy );
    SPF_free_c_results( &best_guess );
    SPF_destroy_default_config();
    
    return res;
}
