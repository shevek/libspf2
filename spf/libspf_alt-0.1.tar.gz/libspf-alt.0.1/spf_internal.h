/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF_INTERNAL
#define INC_SPF_INTERNAL


#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif


/*
 * config
 */
typedef struct 
{
    /*
     * user settable options
     */
    int		client_ver;		/* AF_INET/AF_INET6		*/
    struct in_addr	ipv4;
    struct in6_addr	ipv6;
    char	*env_from;
    char	*helo_dom;
    char	*rec_dom;
    int		max_dns_lookup;
    int		sanitize;
    int		debug;
    SPF_c_results_t	local_policy; /* must be last because compiling uses the config */
    SPF_c_results_t	exp;

    
    /*
     * synthesized from the above inputs
     */
    char	*lp_from;
/*    char	*env_from;	*/
    char	*dp_from;
    char	*cur_dom;
/*    struct in_addr *ip;	*/
/*    time_t	time;		*/	/* current time			*/
    char	*client_dom;
/*    char	*helo_dom;	*/
/*    char	*rec_dom;	*/

    size_t	max_var_len;
} SPF_iconfig_t;

#define SPF_EXP_MOD_NAME	"exp-text"



/*
 * Compiled SPF record
 */

/*
 * The compiled form of the SPF record is as follows:
 *
 * * A four byte header which contains the version, and information
 *   about the mechanisms and modifiers
 *
 * * Mechanism information, repeated once for each mechanism
 *
 *   * A two byte header describing the mechanism
 *
 *   * Data associated with the mechanism.  This can be of several forms
 *
 *     * ip4/ip6 have a fixed format data field, cidr length is in
 *       the mechanism's parm_len field
 *
 *     * Mechanisms that allow a macro-string 
 *
 *       * Optional two byte CIDR length structure.  (Yes, this is at
 *         the beginning, rather than at the end.)
 *
 *       * tokenized data description blocks that can be either:
 *
 *         * two byte macro variable description
 *
 *         * two byte string description, followed by the string
 *
 *   * Modifier information, repeated once for each modifier
 *
 *     * two byte header describing the modifier
 *
 *     * name of the modifier
 *
 *     * tokenized data description blocks that can be either:
 *
 *         * two byte macro variable description
 *
 *         * two byte string description, followed by the string
 */


#define	SPF_MAX_STR_LEN		255	/* limits on SPF_data_str_t.len, */
					/* SPF_mod_t.name_len and	*/
				        /* SPF_mod_t.data_len		*/

#define SPF_MAX_MECH_LEN	511
#define SPF_MAX_MOD_LEN		511


typedef struct 
{
    unsigned int	version:    3;
    unsigned int	num_mech:   6;
    unsigned int	num_mod:    5;
    unsigned int	mech_len:   9;
    unsigned int	mod_len:    9;
} SPF_rec_header_t;


#define PREFIX_PASS	SPF_RESULT_PASS
#define PREFIX_FAIL	SPF_RESULT_FAIL
#define PREFIX_SOFTFAIL	SPF_RESULT_SOFTFAIL
#define PREFIX_NEUTRAL  SPF_RESULT_NEUTRAL
#define PREFIX_UNKNOWN	SPF_RESULT_UNKNOWN



/*
 * Mechanisms
 */

#define MECH_A		1
#define MECH_MX		2
#define MECH_PTR	3
#define MECH_INCLUDE	4
#define MECH_IP4	5
#define MECH_IP6	6
#define MECH_EXISTS	7
#define MECH_ALL	8  
#define MECH_REDIRECT	9


#  if __BYTE_ORDER == __BIG_ENDIAN
struct SPF_mech_struct
{
    unsigned int	prefix_type: 3;
    unsigned int	mech_type:   4;
    unsigned int	parm_len:    9;	/* bytes of data or cidr len	*/
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  elif __BYTE_ORDER == __LITTLE_ENDIAN
struct SPF_mech_struct
{
    unsigned int	parm_len:    9;	/* bytes of data or cidr len	*/
    unsigned int	mech_type:   4;
    unsigned int	prefix_type: 3;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  else
#   error "Adjust your <bits/endian.h> defines"
#  endif
typedef struct SPF_mech_struct SPF_mech_t;
#define NETWORK_SIZEOF_MECH_T	2	/* network format		*/



/*
 * Modifiers
 */

typedef struct {
    unsigned char	name_len;
    unsigned char	data_len;
} SPF_mod_t;
#define NETWORK_SIZEOF_MOD_T	2	/* network format		*/



/*
 * Optional data to mech/mod
 */

#define PARM_LP_FROM	 0		/* l = local-part of envelope-sender */
#define PARM_ENV_FROM	 1		/* s = envelope-sender		*/
#define PARM_DP_FROM	 2		/* o = envelope-domain		*/
#define PARM_CUR_DOM	 3		/* d = current-domain		*/
#define PARM_CLIENT_IP	 4		/* i = SMTP client IP		*/
#define PARM_TIME	 5		/* t = time in UTC epoch secs	*/
#define PARM_CLIENT_DOM	 6		/* p = SMTP client domain name	*/
#define PARM_CLIENT_VER	 7		/* v = IP ver str - in-addr/ip6	*/
#define PARM_HELO_DOM	 8		/* h = HELO/EHLO domain		*/
#define PARM_REC_DOM	 9		/* r = receiving domain		*/
#define PARM_CIDR	10		/* CIDR lengths (IPv4 and v6)	*/
#define PARM_STRING	11		/* literal string		*/


#  if __BYTE_ORDER == __BIG_ENDIAN
struct SPF_data_str_struct
{
    unsigned int	parm_type:   4;
    unsigned int	:	     4;
    unsigned int	len:	     8;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  elif __BYTE_ORDER == __LITTLE_ENDIAN
struct SPF_data_str_struct
{
    unsigned int	len:	     8;
    unsigned int	:	     4;
    unsigned int	parm_type:   4;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  else
#   error "Adjust your <bits/endian.h> defines"
#  endif
typedef struct SPF_data_str_struct SPF_data_str_t;
#define NETWORK_SIZEOF_DATA_STR_T 2	/* network format		*/


#  if __BYTE_ORDER == __BIG_ENDIAN
struct SPF_data_var_struct
{
    unsigned int	parm_type:   4;
    unsigned int	num_rhs:     4;
    unsigned int	rev:	     1;
    unsigned int	url_encode:  1;
    unsigned int	delim_dot:   1;
    unsigned int	delim_dash:  1;
    unsigned int	delim_plus:  1;
    unsigned int	delim_equal: 1;
    unsigned int	delim_bar:   1;
    unsigned int	delim_under: 1;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  elif __BYTE_ORDER == __LITTLE_ENDIAN
struct SPF_data_var_struct
{
    unsigned int	delim_under: 1;
    unsigned int	delim_bar:   1;
    unsigned int	delim_equal: 1;
    unsigned int	delim_plus:  1;
    unsigned int	delim_dash:  1;
    unsigned int	delim_dot:   1;
    unsigned int	url_encode:  1;
    unsigned int	rev:	     1;
    unsigned int	num_rhs:     4;
    unsigned int	parm_type:   4;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  else
#   error "Adjust your <bits/endian.h> defines"
#  endif
typedef struct SPF_data_var_struct SPF_data_var_t;
#define NETWORK_SIZEOF_DATA_VAR_T 2	/* network format		*/


#  if __BYTE_ORDER == __BIG_ENDIAN
struct SPF_data_cidr_struct
{
    unsigned int	parm_type:   4;
    unsigned int	ipv4:	     5;
    unsigned int	ipv6:	     7;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  elif __BYTE_ORDER == __LITTLE_ENDIAN
struct SPF_data_cidr_struct
{
    unsigned int	ipv6:	     7;
    unsigned int	ipv4:	     5;
    unsigned int	parm_type:   4;
} __attribute__ ((packed));		/* FIXME: remove packed		*/
#  else
#   error "Adjust your <bits/endian.h> defines"
#  endif
typedef struct SPF_data_cidr_struct  SPF_data_cidr_t;
#define NETWORK_SIZEOF_DATA_CIDR_T 2	/* network format		*/


typedef union
{
    SPF_data_var_t	dv;
    SPF_data_str_t	ds;
    SPF_data_cidr_t	dc;
} SPF_data_t;
#define NETWORK_SIZEOF_DATA_T	2	/* network format		*/



/*
 * Compiled SPF records as used internally by libspf-alt
 */

typedef struct
{
    SPF_rec_header_t	header;

    SPF_mech_t		*mech_first;
    SPF_mech_t		*mech_last;
    size_t		mech_buf_len;
    size_t		mech_len;	/* non-network format		*/

    SPF_mod_t		*mod_first;
    SPF_mod_t		*mod_last;
    size_t		mod_buf_len;
    size_t		mod_len;	/* non-network format		*/
} SPF_internal_t;



/*
 * misc macros to make the code look cleaner than it really is
 */

#ifndef SPF_MAX_DNS_LOOKUP
/* It is a bad idea to change this for two reasons.
 *
 * First, the obvious reason is the delays caused on the mail server
 * you are running.  DNS lookups that timeout can be *very* time
 * consuming, and even successful DNS lookups can take 200-500ms.
 * MTAs can't afford to wait long and even 2sec is pretty bad.
 *
 * The second, and more important reason, is the SPF records come from
 * a third party which may be malicious.  This third party can direct
 * DNS lookups to be sent to anyone.  If there isn't a limit, then it
 * is easy for someone to create a distributed denial of service
 * attack simply by sending a bunch of emails.  Unlike the delays on
 * your system caused by many DNS lookups, you might not even notice
 * that you are being used as part of a DDoS attack.
 */
#define SPF_MAX_DNS_LOOKUP 10
#endif


static inline SPF_internal_t *SPF_id2spfi( SPF_id_t spfid ) 
    { return (SPF_internal_t *)spfid; }
static inline SPF_id_t SPF_spfi2id( SPF_internal_t *spfi ) 
    { return (SPF_id_t)spfi; }

static inline SPF_iconfig_t *SPF_cid2spfic( SPF_config_t spfcid ) 
    { return (SPF_iconfig_t *)spfcid; }
static inline SPF_config_t SPF_spfic2cid( SPF_iconfig_t *spfic ) 
    { return (SPF_config_t)spfic; }
  
/* FIXME: need to make these network/compiler portable	*/
static inline size_t SPF_mech_data_len( SPF_mech_t * mech )
    { return (mech->mech_type == MECH_IP4) ? sizeof( struct in_addr ) : (mech->mech_type == MECH_IP6) ? sizeof( struct in6_addr ) : mech->parm_len; }
static inline SPF_mech_t *SPF_next_mech( SPF_mech_t * mech )
    { return (SPF_mech_t *)( (char *)mech + sizeof(SPF_mech_t) + SPF_mech_data_len( mech ));}
static inline SPF_data_t *SPF_mech_data( SPF_mech_t *mech )
    { return (SPF_data_t *)( (char *)mech + sizeof(SPF_mech_t)); }
static inline SPF_data_t *SPF_mech_end_data( SPF_mech_t *mech )
    { return (SPF_data_t *)( (char *)SPF_next_mech(mech)); }
static inline struct in_addr *SPF_mech_ip4_data( SPF_mech_t *mech )
    { return (struct in_addr *)( (char *)mech + sizeof(SPF_mech_t)); }
static inline struct in6_addr *SPF_mech_ip6_data( SPF_mech_t *mech )
    { return (struct in6_addr *)( (char *)mech + sizeof(SPF_mech_t)); }

static inline SPF_data_t *SPF_next_data( SPF_data_t *data )
    { return (SPF_data_t *)( (char *)data + sizeof(SPF_data_t) + (data->ds.parm_type == PARM_STRING ? data->ds.len : 0)); }
static inline char *SPF_data_str( SPF_data_t *data )
    { return (char *)data + sizeof(SPF_data_t); }

static inline SPF_mod_t *SPF_next_mod( SPF_mod_t *mod )
    { return (SPF_mod_t *)( (char *)mod + sizeof(SPF_mod_t) + mod->name_len + mod->data_len); }
static inline char *SPF_mod_name( SPF_mod_t *mod )
    { return (char *)mod + sizeof(SPF_mod_t); }
static inline SPF_data_t *SPF_mod_data( SPF_mod_t *mod )
    { return (SPF_data_t *)((char *)mod + sizeof(SPF_mod_t) + mod->name_len); }
static inline SPF_data_t *SPF_mod_end_data( SPF_mod_t *mod )
    { return (SPF_data_t *)((char *)SPF_mod_data(mod) + mod->data_len); }


SPF_err_t SPF_expand( SPF_config_t spfcid, SPF_dns_config_t spfdc,
		SPF_data_t *data, size_t data_len,
		char **buf, size_t *buf_len);
SPF_err_t SPF_find_mod_data( SPF_config_t spfcid, SPF_id_t spfid, char *mod_name,
		       SPF_data_t **data, size_t *data_len );

SPF_err_t SPF_compile_exp( SPF_config_t spfcid, char *exp, SPF_c_results_t *c_results );


void (*SPF_error_handler)(char *, int, char *) __attribute__ ((noreturn));
void SPF_error_stderr( char *file, int line, char *errmsg ) __attribute__ ((noreturn));

void (*SPF_warning_handler)(char *, int, char *);
void SPF_warning_stderr( char *file, int line, char *errmsg );

/* oh, btw, fuck-you sysv */
#define SPF_snprintf	snprintf


SPF_output_t SPF_eval_id( SPF_config_t spfcid, SPF_id_t spfid,
			    SPF_dns_config_t spfdcid,
			    int *num_dns_mech, int use_local_policy );

char *SPF_sanitize( SPF_config_t spfcid, char *str );
int SPF_is_loopback( SPF_config_t spfcid );


#endif
