/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF_DNS
#define INC_SPF_DNS


/*
 * For those who don't have <arpa/nameserv.h>
 */

#if !defined( _ARPA_NAMESER_H_ )  &&  !defined( ns_t_invalid )

#define	ns_t_invalid	0
#define	ns_t_a		1
#define	ns_t_ns		2
#define	ns_t_cname	5
#define	ns_t_ptr	12
#define	ns_t_mx		15
#define	ns_t_txt	16
#define ns_t_a6		38

typedef int	ns_type;
#endif


/*
 * For those who don't have <netdb.h>
 */

#if !defined( _NETDB_H )  &&  !defined( NETDB_SUCCESS )
#define NETDB_SUCCESS	0
#define	HOST_NOT_FOUND 	1
#define	TRY_AGAIN	2
#define	NO_RECOVERY	3
#define	NO_DATA		4
#endif
typedef int SPF_dns_stat_t;




/*
 * bundle up the info needed to use a dns method
 */


void SPF_dns_destroy_config( SPF_dns_config_t spfdcid );

int SPF_dns_cached( SPF_dns_config_t spfdcid,
			       char *domain, ns_type rr_type );


/*
 * helper functions
 */


#if __BYTE_ORDER == __BIG_ENDIAN
#define SPF_IPV4(a,b,c,d) ((a<<24) + (b<<16) + (c<<8) + d)
#else
#define SPF_IPV4(a,b,c,d) ((d<<24) + (c<<16) + (b<<8) + a)
#endif



#endif
