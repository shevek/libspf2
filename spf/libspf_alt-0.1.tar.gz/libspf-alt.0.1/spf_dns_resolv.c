/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <netdb.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"
#include "spf_dns_resolv.h"


typedef struct
{
    int		debug;
    SPF_dns_rr_t spfrr;
} SPF_dns_resolv_config_t; 


static inline SPF_dns_resolv_config_t *SPF_voidp2spfhook( void *hook ) 
    { return (SPF_dns_resolv_config_t *)hook; }
static inline void *SPF_spfhook2voidp( SPF_dns_resolv_config_t *spfhook ) 
    { return (void *)spfhook; }



static SPF_dns_rr_t *SPF_dns_lookup_resolv( SPF_dns_config_t spfdcid, char *domain, int rr_type, int should_cache )
{
    SPF_dns_iconfig_t		*spfdic = SPF_dcid2spfdic( spfdcid );
    SPF_dns_resolv_config_t	*spfhook = SPF_voidp2spfhook( spfdic->hook );
    SPF_dns_rr_t *spfrr;

    int		err;
    int		i;
    int		nrec;
    int		cnt;

    u_char	response[2048];

    int		dns_len;
    
    ns_msg	ns_handle;
    ns_rr	rr;

    int		ns_sects[] = { ns_s_qd, ns_s_an, ns_s_ns, ns_s_ar }; 
    char	*ns_sect_names[] = { "Question", "Answer", "Authority", "Additional" }; 
    int		ns_sect;
    int		num_ns_sect = sizeof( ns_sects ) / sizeof( *ns_sects );
    
    char	ip4_buf[ INET_ADDRSTRLEN ];
    char	name_buf[ MAXDNAME ];
    int		prio;
    
    int		rdlen;
    const u_char	*rdata, *rdata_end;
    
    
    /*
     * initialize stuff
     */
    spfrr = &spfhook->spfrr;
    SPF_dns_reset_rr( spfrr );
    spfhook->spfrr.herrno = NO_RECOVERY;
    spfhook->spfrr.domain = strdup( domain );
    spfhook->spfrr.rr_type = rr_type;
    cnt = 0;
        
    if ( spfhook->debug )
	fprintf( stderr, "DNS resolv looking for:  %s  %s (%d)\n",
		 domain,
		 ( (rr_type == ns_t_a)   ? "A" :
		   (rr_type == ns_t_a6)  ? "A6" :
		   (rr_type == ns_t_mx)  ? "MX" :
		   (rr_type == ns_t_txt) ? "TXT" :
		   (rr_type == ns_t_ptr) ? "PTR" :
		   "??" ),
		 rr_type );

    
    /*
     * try resolving the name
     */
    dns_len = res_query( domain, ns_c_in, rr_type,
		    response, sizeof( response ) );

    if ( dns_len < 0 )
    {
	if ( spfhook->debug )
	    printf( "query failed: err = %d  %s (%d)\n",
		    dns_len, hstrerror( h_errno ), h_errno );

	spfrr->herrno = h_errno;

	if ( spfrr->herrno == HOST_NOT_FOUND && spfdic->layer_below )
	    return SPF_dcid2spfdic( spfdic->layer_below )->lookup( spfdic->layer_below, domain, rr_type, should_cache );

	return spfrr;
    }
    else
	spfrr->herrno = NETDB_SUCCESS;
	
    
    err = ns_initparse( response, dns_len, &ns_handle );

    if ( err < 0 )			/* 0 or -1 */
    {
	if ( spfhook->debug )
	    printf( "ns_initparse failed: err = %d  %s (%d)\n",
		    err, strerror( errno ), errno );
	return spfrr;
    }

    
    if ( spfhook->debug > 1 )
    {
	printf( "msg id:             %d\n", ns_msg_id( ns_handle ));
	printf( "ns_f_qr quest/resp: %d\n", ns_msg_getflag( ns_handle, ns_f_qr ));
	printf( "ns_f_opcode:        %d\n", ns_msg_getflag( ns_handle, ns_f_opcode ));
	printf( "ns_f_aa auth ans:   %d\n", ns_msg_getflag( ns_handle, ns_f_aa ));
	printf( "ns_f_tc truncated:  %d\n", ns_msg_getflag( ns_handle, ns_f_tc ));
	printf( "ns_f_rd rec desire: %d\n", ns_msg_getflag( ns_handle, ns_f_rd ));
	printf( "ns_f_ra rec avail:  %d\n", ns_msg_getflag( ns_handle, ns_f_ra ));
	printf( "ns_f_rcode:         %d\n", ns_msg_getflag( ns_handle, ns_f_rcode ));
    }
    

    /* FIXME  the error handling from here on is suspect at best */
    for( ns_sect = 0; ns_sect < num_ns_sect; ns_sect++ )
    {
	if ( ns_sects[ ns_sect ] != ns_s_an )
	    continue;

	nrec = ns_msg_count( ns_handle, ns_sects[ ns_sect ] );

	if ( spfhook->debug > 1 )
	    printf( "%s:  %d\n", ns_sect_names[ns_sect], nrec );

	spfrr->rr = malloc( nrec * sizeof( *spfrr->rr ) );
	if ( spfrr->rr == NULL )
	    return spfrr;
	memset( spfrr->rr, 0, nrec * sizeof( *spfrr->rr ) );

	spfrr->num_rr = 0;
	cnt = 0;
	for( i = 0; i < nrec; i++ )
	{
	    err = ns_parserr( &ns_handle, ns_sects[ ns_sect ], i, &rr );
	    if ( err < 0 )		/* 0 or -1 */
	    {
		if ( spfhook->debug > 1 )
		    printf( "ns_parserr failed: err = %d  %s (%d)\n",
			    err, strerror( errno ), errno );
		return spfrr;
	    }

	    rdlen = ns_rr_rdlen( rr );
	    if ( spfhook->debug > 1 )
		printf( "name: %s  type: %d  class: %d  ttl: %d  rdlen: %d\n",
			ns_rr_name( rr ), ns_rr_type( rr ), ns_rr_class( rr ),
			ns_rr_ttl( rr ), rdlen );

	    if ( rdlen <= 0 )
		continue;
	    
	    rdata = ns_rr_rdata( rr );

	    if ( spfhook->debug > 1 )
	    {
		switch( ns_rr_type( rr ) )
		{
		case ns_t_a:
		    printf( "A: %s\n",
			    inet_ntop( AF_INET, rdata,
				       ip4_buf, sizeof( ip4_buf ) ));
		    break;
		
		case ns_t_ns:
		    err = ns_name_uncompress( response,
					      response + sizeof( response ),
					      rdata,
					      name_buf, sizeof( name_buf ) );
		    if ( err < 0 )		/* 0 or -1 */
		    {
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    }
		    else
			printf( "NS: %s\n", name_buf );
		    break;
		
		case ns_t_cname:
		    err = ns_name_uncompress( response,
					      response + sizeof( response ),
					      rdata,
					      name_buf, sizeof( name_buf ) );
		    if ( err < 0 )		/* 0 or -1 */
		    {
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    }
		    else
			printf( "CNAME: %s\n", name_buf );
		    break;
		
		case ns_t_mx:
		    prio = ns_get16( rdata );
		    err = ns_name_uncompress( response,
					      response + sizeof( response ),
					      rdata + NS_INT16SZ,
					      name_buf, sizeof( name_buf ) );
		    if ( err < 0 )		/* 0 or -1 */
		    {
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    }
		    else
			printf( "MX: %d %s\n", prio, name_buf );
		    break;
		
		case ns_t_txt:
		    rdata_end = rdata + rdlen;
		    printf( "TXT: (%d) \"%.*s\"\n",
			    rdlen, rdlen-1, rdata+1 );
		    break;
		
		case ns_t_ptr:
		    err = ns_name_uncompress( response,
					      response + sizeof( response ),
					      rdata,
					      name_buf, sizeof( name_buf ) );
		    if ( err < 0 )		/* 0 or -1 */
		    {
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    }
		    else
			printf( "PTR: %s\n", name_buf );
		    break;
		
		default:
		    printf( "not parsed:  type: %d\n", ns_rr_type( rr ) );
		    break;
		}
	    }

	    if ( ns_sects[ ns_sect ] != ns_s_an  &&  spfhook->debug > 1 )
		continue;


	    if ( ns_rr_type( rr ) != spfrr->rr_type
		 && ns_rr_type( rr ) != ns_t_cname )
	    {
		printf( "unexpected rr type: %d   expected: %d\n",
			ns_rr_type( rr ), rr_type );
		continue;
	    }

	    switch( ns_rr_type( rr ) )
	    {
	    case ns_t_a:
		spfrr->rr[cnt].a = *(struct in_addr *)rdata;

		cnt++;
		break;
		
	    case ns_t_ns:
		break;
		
	    case ns_t_cname:
		break;
		
	    case ns_t_mx:
		err = ns_name_uncompress( response,
					  response + sizeof( response ),
					  rdata + NS_INT16SZ,
					  name_buf, sizeof( name_buf ) );
		if ( err < 0 )		/* 0 or -1 */
		{
		    if ( spfhook->debug > 1 )
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    return spfrr;
		}
		    
		spfrr->rr[cnt].mx = strdup( name_buf );
		if ( spfrr->rr[cnt].mx == NULL )
		    return spfrr;

		cnt++;
		break;
		
	    case ns_t_txt:
		if ( rdlen > 1 )
		{
		    spfrr->rr[cnt].txt = malloc( rdlen );
		    if ( spfrr->rr[cnt].txt == NULL )
			return spfrr;
		    memcpy( spfrr->rr[cnt].txt, rdata+1, rdlen-1 );
		    spfrr->rr[cnt].txt[rdlen-1] = '\0';
		} else {
		    spfrr->rr[cnt].txt = strdup( "" );
		    if ( spfrr->rr[cnt].txt == NULL )
			return spfrr;
		}

		cnt++;
		break;
		
	    case ns_t_ptr:
		err = ns_name_uncompress( response,
					  response + sizeof( response ),
					  rdata,
					  name_buf, sizeof( name_buf ) );
		if ( err < 0 )		/* 0 or -1 */
		{
		    if ( spfhook->debug > 1 )
			printf( "ns_name_uncompress failed: err = %d  %s (%d)\n",
				err, strerror( errno ), errno );
		    return spfrr;
		}

		spfrr->rr[cnt].ptr = strdup( name_buf );
		if ( spfrr->rr[cnt].ptr == NULL )
		    return spfrr;

		cnt++;
		break;
		
	    default:
		break;
	    }		    

	}

	spfrr->num_rr = cnt;
    }

    if ( spfrr->num_rr == 0 )
    {
	if ( spfrr->rr ) free( spfrr->rr );
	spfrr->rr = NULL;
	spfhook->spfrr.herrno = NO_DATA;
    }
    return spfrr;
}


static int SPF_dns_cached_resolv( SPF_dns_config_t spfdcid, char *domain, int rr_type )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    
    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->cached( spfdic->layer_below, domain, rr_type );
    else
	return FALSE;
}


SPF_dns_config_t SPF_dns_create_config_resolv( SPF_dns_config_t layer_below, int debug )
{
    SPF_dns_iconfig_t     *spfdic;
    SPF_dns_resolv_config_t *spfhook;

#if 0
    SPF_dns_rr_t	*junk, *junk2;

    junk = SPF_dns_create_rr();
    junk->domain = strdup( "asdf" );
    junk->num_rr = 1;
    junk->rr = malloc( junk->num_rr * sizeof( *junk->rr ) );
    junk->rr[0].txt = strdup( "v=spf1 -all" );
    SPF_dns_reset_rr( junk );
    SPF_dns_destroy_rr( junk );
    junk = NULL;
    
    
    junk = SPF_dns_create_rr();
    junk->domain = strdup( "asdf" );
    junk->num_rr = 1;
    junk->rr = malloc( junk->num_rr * sizeof( *junk->rr ) );
    junk->rr[0].txt = strdup( "v=spf1 -all" );
    junk2 = SPF_dns_dup_rr( junk );
    SPF_dns_reset_rr( junk );
    SPF_dns_destroy_rr( junk );
    junk = NULL;
    SPF_dns_destroy_rr( junk2 );
    junk2 = NULL;
#endif    
    

    
    spfdic = malloc( sizeof( *spfdic ) );
    if ( spfdic == NULL )
	return NULL;

    spfdic->hook = malloc( sizeof( SPF_dns_resolv_config_t ) );
    if ( spfdic->hook == NULL )
    {
	free( spfdic );
	return NULL;
    }
    
    spfdic->destroy  = SPF_dns_destroy_config_resolv;
    spfdic->lookup   = SPF_dns_lookup_resolv;
    spfdic->cached   = SPF_dns_cached_resolv;
    spfdic->get_spf  = NULL;
    spfdic->get_exp  = NULL;
    spfdic->layer_below = layer_below;
    
    spfhook = SPF_voidp2spfhook( spfdic->hook );
    memset( spfdic->hook, 0, sizeof( *spfhook ) );

    spfhook->debug = debug;
    SPF_dns_reset_rr( &spfhook->spfrr );

    return SPF_spfdic2dcid( spfdic );
}

void SPF_dns_reset_config_resolv( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t    *spfdic = SPF_dcid2spfdic( spfdcid );


    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );


    SPF_dns_reset_rr( &(SPF_voidp2spfhook( spfdic->hook )->spfrr) );
}

void SPF_dns_destroy_config_resolv( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    SPF_dns_reset_config_resolv( spfdcid );

    if ( spfdic->hook )
	free( spfdic->hook );
    if ( spfdic )
	free( spfdic );
}
