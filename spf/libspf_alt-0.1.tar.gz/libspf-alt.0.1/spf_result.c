/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"



char *SPF_header_comment( SPF_config_t spfcid, SPF_output_t output )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);
    char		*spf_source;
    
    size_t		len;

    char	ip4_buf[ INET_ADDRSTRLEN ];
    char	ip6_buf[ INET6_ADDRSTRLEN ];
    const char	*ip;

    char	*buf;
    char	*sender_dom;
    
    if ( output.result == SPF_RESULT_PASS
	 && output.reason == SPF_REASON_LOCALHOST )
	return strdup( "localhost is always allowed." );
    
    
    sender_dom = spfic->dp_from;
    if ( sender_dom == NULL ) sender_dom = spfic->helo_dom;
	

    if ( output.reason == SPF_REASON_LOCAL_POLICY )
	spf_source = strdup( "local policy" );
    else if ( sender_dom == NULL )
	spf_source = strdup( "unknown domain" );
    else
    {
	len = strlen( sender_dom ) + sizeof( "domain of " );
	spf_source = malloc( len );
	if ( spf_source )
	    SPF_snprintf( spf_source, len, "domain of %s", sender_dom );
    }

    if ( spf_source == NULL )
	return NULL;

    ip = NULL;
    if ( spfic->client_ver == AF_INET )
    {
	ip = inet_ntop( AF_INET, &spfic->ipv4,
			ip4_buf, sizeof( ip4_buf ) );
    }
    else if (spfic->client_ver == AF_INET6 )
    {
	ip = inet_ntop( AF_INET6, &spfic->ipv6,
			ip6_buf, sizeof( ip6_buf ) );
    }

    if ( ip == NULL )
	ip = "<unknown ip address>";
    

    len = strlen( spf_source ) + strlen( ip ) + 80;
    buf = malloc( len );
    if ( buf == NULL )
    {
	free( spf_source );
	return NULL;
    }
    
    switch( output.result)
    {
    case SPF_RESULT_PASS:
	SPF_snprintf( buf, len, "%s designates %s as permitted sender",
		  spf_source, ip );
	break;

    case SPF_RESULT_FAIL:
	SPF_snprintf( buf, len, "%s does not designate %s as permitted sender",
		  spf_source, ip );
	break;

    case SPF_RESULT_SOFTFAIL:
	SPF_snprintf( buf, len, "transitioning %s does not designate %s as permitted sender",
		  spf_source, ip );
	break;

    case SPF_RESULT_UNKNOWN:
	SPF_snprintf( buf, len, "error in processing during lookup of %s: %s",
		      spf_source, SPF_strerror( output.err ) );
	break;
	
    case SPF_RESULT_NEUTRAL:
    case SPF_RESULT_NONE:
	SPF_snprintf( buf, len, "%s is neither permitted nor denied by %s",
		  ip, spf_source );
	break;

    case SPF_RESULT_ERROR:
	SPF_snprintf( buf, len, "encountered temporary error during SPF processing of %s",
		  spf_source );
	break;


    default:
	SPF_snprintf( buf, len, "error: unknown SPF result %d encountered while checking %s for %s",
		  output.result, ip, spf_source );
	break;
    }
    
    if( spf_source ) free( spf_source );

    return buf;
}



char *SPF_received_spf( SPF_config_t spfcid, SPF_output_t output )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);
    
    char	ip4_buf[ INET_ADDRSTRLEN ];
    char	ip6_buf[ INET6_ADDRSTRLEN ];
    const char	*ip;

    char	*buf;
    size_t	buf_len = 5*80;
    
    char	*p, *p_end;


    buf = malloc( buf_len );
    if ( buf == NULL )
	return buf;
    
    p = buf;
    p_end = p + buf_len;

    
    /* create the stoc Received-SPF: header */
    p += snprintf( p, p_end - p, "Received-SPF: %s (%s: %s)",
		   SPF_strresult( output.result ), spfic->rec_dom,
		   output.header_comment );
    if ( p_end - p <= 0 ) return buf;

    
    
    /* add in the optional ip address keyword */
    ip = NULL;
    if ( spfic->client_ver == AF_INET )
    {
	ip = inet_ntop( AF_INET, &spfic->ipv4,
			ip4_buf, sizeof( ip4_buf ) );
    }
    else if (spfic->client_ver == AF_INET6 )
    {
	ip = inet_ntop( AF_INET6, &spfic->ipv6,
			ip6_buf, sizeof( ip6_buf ) );
    }

    if ( ip != NULL )
    {
	p += snprintf( p, p_end - p, " client-ip=%s;", ip );
	if ( p_end - p <= 0 ) return buf;
    }
    

    /* add in the optional envelope-from keyword */
    if ( spfic->env_from != NULL )
    {
	p += snprintf( p, p_end - p, " envelope-from=%s;", spfic->env_from );
	if ( p_end - p <= 0 ) return buf;
    }
    

    /* add in the optional helo domain keyword */
    if ( spfic->helo_dom != NULL )
    {
	p += snprintf( p, p_end - p, " helo=%s;", spfic->helo_dom );
	if ( p_end - p <= 0 ) return buf;
    }
    

    /* add in the optional compiler error keyword */
    if ( output.err_msg != NULL )
    {
	p += snprintf( p, p_end - p, " problem=%s;", output.err_msg );
	if ( p_end - p <= 0 ) return buf;
    }
    
    /* FIXME  should the header be reformated to include line breaks? */

    return buf;
}



void SPF_result_comments( SPF_config_t spfcid, SPF_id_t spfid,
				  SPF_dns_config_t spfdcid,
				  SPF_output_t *output )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);
    SPF_err_t		err;
    char		*err_buf;
    size_t		len;

    char		*buf;
    size_t		buf_len;



    
    /* smtp_comment = exp= + <why string> */
    if ( output->result != SPF_RESULT_PASS  &&  spfid != NULL )
    {
	/* FIXME this code sux.  Allocate a big buffer, don't display
	 * anything if malloc fails and truncate if the message is
	 * too long */

	buf = output->smtp_comment;
	buf_len = 0;
	err = SPF_get_exp( spfcid, spfid, spfdcid, &buf, &buf_len );


	if ( err == SPF_E_SUCCESS )
	{
	    if ( buf == NULL ) buf = strdup( "" );

	    /* FIXME  this isn't quite the same as the perl "$smtp_why" */

	    if ( buf )
	    {
		if ( output->reason != SPF_REASON_MECH )
		{
		    err_buf = SPF_strreason( output->reason );
	    
		    len = strlen( err_buf ) + strlen( buf ) + sizeof( " : ");
		    output->smtp_comment = malloc( len );

		    if ( output->smtp_comment == NULL )
			output->smtp_comment = SPF_sanitize( spfcid, buf );
		    else
			SPF_snprintf( output->smtp_comment, len, "%s : %s",
				      SPF_sanitize( spfcid, buf ), err_buf );
		    free( buf );
		}
		else 
		    output->smtp_comment = SPF_sanitize( spfcid, buf );
	    }
	    else
		output->smtp_comment = NULL;
	    
	} else {

	    if ( buf == NULL ) buf = strdup( "" );

	    /* FIXME  this isn't quite the same as the perl "$smtp_why" */

	    err_buf = SPF_strerror( err );
	    
	    if ( buf )
	    {
		if ( spfic->debug > 0 )
		    printf( "Error formatting explanation string:  %s\n",
			    err_buf );

		len = strlen( err_buf ) + strlen( buf ) + sizeof( " : ");
		output->smtp_comment = malloc( len );

		if ( output->smtp_comment == NULL )
		    output->smtp_comment = SPF_sanitize( spfcid, buf );
		else
		    SPF_snprintf( output->smtp_comment, len, "%s : %s",
				  SPF_sanitize( spfcid, buf ), err_buf );
		free( buf );
	    }
	    else
		output->smtp_comment = NULL;
	}
    }
    

    /* header_comment = <list based off of SPF_result_t> */
    buf = SPF_header_comment( spfcid, *output );
    if ( buf )
    {
	if ( output->header_comment ) free( output->header_comment );
	output->header_comment = SPF_sanitize( spfcid, buf );
    }

    

    /* received_spf = <list based off of SPF_result_t> */
    buf = SPF_received_spf( spfcid, *output );
    if ( buf )
    {
	if ( output->received_spf ) free( output->received_spf );
	output->received_spf = SPF_sanitize( spfcid, buf );
    }

}




SPF_output_t SPF_result( SPF_config_t spfcid, SPF_dns_config_t spfdcid,
			 char *domain )
{
    SPF_output_t	output;
    SPF_err_t		err;
    SPF_c_results_t	c_results;



    SPF_init_output( &output );

    SPF_init_c_results( &c_results );


    /*
     * get the (compiled) SPF record
     */
    
    if ( !SPF_is_loopback( spfcid ) )
    {
	err = SPF_get_spf( spfcid, spfdcid, domain, &c_results );
	if ( err )
	{
	    if ( err == SPF_E_NOT_SPF )
		output.result = SPF_RESULT_NONE;
	    else
		output.result = SPF_RESULT_UNKNOWN;
	    output.reason = SPF_REASON_NONE;
	    output.err = err;
	    if ( output.err_msg ) free( output.err_msg );
	    if ( c_results.err_msg )
		output.err_msg = strdup( c_results.err_msg );
	    else
		output.err_msg = NULL;
	
	} else {
	    
	    /*
	     * find out whether this configuration passes
	     */

	    output = SPF_eval_id( spfcid, c_results.spfid, spfdcid, NULL, TRUE );
	}
	
    } else {
	
	output.result = SPF_RESULT_PASS;
	output.reason = SPF_REASON_LOCALHOST;
	output.err = SPF_E_SUCCESS;
    }
    

    SPF_result_comments( spfcid, c_results.spfid, spfdcid, &output );

    SPF_free_c_results( &c_results );
    return output;
}





SPF_output_t SPF_result_id( SPF_config_t spfcid, SPF_id_t spfid, SPF_dns_config_t spfdcid )
{
    SPF_output_t	output;


    if ( spfcid == NULL )
	SPF_error( "spfcid is null" );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    if ( spfid == NULL )
	SPF_error( "spfid is null" );

    SPF_init_output( &output );
    

    /*
     * find out whether this configuration passes
     */

    output = SPF_eval_id( spfcid, spfid, spfdcid, NULL, TRUE );
    
    SPF_result_comments( spfcid, spfid, spfdcid, &output );

    return output;
}





#if 0
SPF_output_t SPF_result_mx( SPF_config_t spfcid, SPF_id_t spfid,
			    SPF_dns_config_t spfdc,
			    char *rcpt_to )
{
}


SPF_output_t SPF_result_mx_msg( SPF_config_t spfcid, SPF_id_t spfid,
				SPF_dns_config_t spfdc );
#endif



char *SPF_strresult( SPF_result_t result )
{
    switch( result )
    {
    case SPF_RESULT_PASS:		/* +				*/
	return "pass";
	break;

    case SPF_RESULT_FAIL:		/* -				*/
	return "fail";
	break;

    case SPF_RESULT_SOFTFAIL:		/* ~				*/
	return "softfail";
	break;

    case SPF_RESULT_NEUTRAL:		/* ?				*/
	return "neutral";
	break;

    case SPF_RESULT_UNKNOWN:		/* permanent error		*/
	return "unknown";
	break;

    case SPF_RESULT_ERROR:		/* temporary error		*/
	return "error";
	break;

    case SPF_RESULT_NONE:		/* no SPF record found		*/
	return "none";
	break;

    default:
	return "invalid-result";
	break;
    }
}


char *SPF_strreason( SPF_reason_t reason )
{
    switch( reason )
    {
    case SPF_REASON_NONE:
	return "none";
	break;
	
    case SPF_REASON_LOCALHOST:
	return "localhost";
	break;
	
    case SPF_REASON_LOCAL_POLICY:
	return "local policy";
	break;
	
    case SPF_REASON_MECH:
	return "mechanism";
	break;
	
    case SPF_REASON_DEFAULT:
	return "default";
	break;
	
    default:
	return "<invalid reason>";
	break;
	
    }
}




void SPF_init_output( SPF_output_t *output )
{
    memset( output, 0, sizeof( *output ) );
}


void SPF_free_output( SPF_output_t *output )
{
    if ( output->err_msg ) free( output->err_msg );
    if ( output->smtp_comment ) free( output->smtp_comment );
    if ( output->header_comment ) free( output->header_comment );
    if ( output->received_spf ) free( output->received_spf );

    SPF_init_output( output );
}


