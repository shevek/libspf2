/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */



#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "spf.h"

void SPF_error_stderr( char *file, int line, char *errmsg )
{
    fprintf( stderr, "%s:%d Error: %s\n", file, line, errmsg );
    abort();
}

void SPF_warning_stderr( char *file, int line, char *errmsg )
{
    fprintf( stderr, "%s:%d Warning: %s\n", file, line, errmsg );
}


/* FIXME  create syslog versions */
