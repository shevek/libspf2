/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF
#define INC_SPF

/*
 * we use the in_addr and in6_addr structs all over the place.  Every file
 * that includes spf.h needs them.
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#include "spf_lib_version.h"


#define SPF_VERSION 1
#define SPF_VER_STR "v=spf1"


/*
 * object handles for SPF related data
 */
typedef struct {} *SPF_id_t;		/* SPF record			*/
typedef struct {} *SPF_config_t;	/* SPF library configuartion	*/
typedef struct {} *SPF_dns_config_t;	/* SPF DNS layer configuartion	*/


/*
 * error codes returned by various SPF functions.  (including SPF_compile()
 * and SPF_id2str(), spf_result(), etc.).
 *
 * The function SPF_strerror() will return a longer explanation of these
 * errors.
 */

typedef int SPF_err_t;

#define SPF_E_SUCCESS		 0
#define SPF_E_NO_MEMORY		 1
#define SPF_E_NOT_SPF		 2
#define SPF_E_SYNTAX		 3
#define SPF_E_MOD_W_PREF	 4
#define SPF_E_INVALID_CHAR	 5
#define SPF_E_UNKNOWN_MECH	 6
#define SPF_E_INVALID_OPT	 7
#define SPF_E_INVALID_CIDR	 8
#define SPF_E_MISSING_OPT	 9
#define SPF_E_INTERNAL_ERROR	10
#define SPF_E_INVALID_ESC	11
#define SPF_E_INVALID_VAR	12
#define SPF_E_BIG_SUBDOM	13
#define SPF_E_INVALID_DELIM	14
#define SPF_E_BIG_STRING	15
#define SPF_E_BIG_MECH		16
#define SPF_E_BIG_MOD		17
#define SPF_E_BIG_DNS		18
#define SPF_E_INVALID_IP4	19
#define SPF_E_INVALID_IP6	20
#define SPF_E_INVALID_PREFIX	21
#define SPF_E_RESULT_UNKNOWN	22
#define SPF_E_UNINIT_VAR	23
#define SPF_E_MOD_NOT_FOUND	24
#define SPF_E_NOT_CONFIG	25
#define SPF_E_DNS_ERROR		26


/* ********************************************************************* */

/*
 * SPF record object managment
 */
SPF_id_t SPF_create_id();
void SPF_reset_id( SPF_id_t spfid );
void SPF_destroy_id( SPF_id_t spfid );
SPF_id_t SPF_dup_id( SPF_id_t src_spfid );



/*
 * SPF record byte-compiler
 */

typedef struct
{
    SPF_id_t	spfid;
    SPF_err_t	err;
    char	*err_msg;
    

    /*
     * these pointers refer to places in the text SPF record and will
     * become invalid when the caller of spf_compile chooses.
     *
     * don't use them if you don't control the text SPF record!
     */
    char	*expression;	/* the complete mech/mod with the error	*/
    int		expression_len;
    char	*token;		/* the token within the expression	*/
    int		token_len;
    char	*error_loc;	/* exact char within the token		*/
} SPF_c_results_t;
    

SPF_err_t SPF_compile( SPF_config_t spfcid, char *record, SPF_c_results_t *c_results );
char *SPF_strerror( SPF_err_t spf_err );

SPF_err_t SPF_verify( SPF_config_t spfcid, SPF_id_t spfid );

SPF_err_t SPF_optimize( SPF_config_t spfcid, SPF_id_t *dst_spfid, SPF_id_t src_spfid );

void SPF_init_c_results( SPF_c_results_t *c_results );
void SPF_free_c_results( SPF_c_results_t *c_results );

/* FYI only -- can't be changed without recompiling the library
 * Most error messages are under 80 characters and we don't want
 * bad/malicious input to cause huge error messages */
#define SPF_C_ERR_MSG_SIZE		160


/* ********************************************************************* */

/*
 * SPF configuration object managment
 */

SPF_config_t SPF_create_config();
void SPF_reset_config( SPF_config_t spfcid );
void SPF_destroy_config( SPF_config_t spfcid );
SPF_config_t SPF_dup_config( SPF_config_t src_spfcid );
void SPF_destroy_default_config();

/* FYI only -- defaults can't be changed without recompiling the library */
#define SPF_DEFAULT_EXP			"Please see http://spf.pobox.com/why.html?sender=%{S}&ip=%{I}&receiver=%{R}"
#define SPF_DEFAULT_MAX_DNS_LOOKUP	10
#define SPF_DEFAULT_SANITIZE		 1
#define SPF_DEFAULT_WHITELIST		"include:spf.trusted-forwarder.org"


int	SPF_set_ipv4_str( SPF_config_t spfcid, char *ipv4_address );
int	SPF_set_ipv4( SPF_config_t spfcid, struct in_addr ipv4 );
struct in_addr  SPF_get_ipv4( SPF_config_t spfcid );

int	SPF_set_ipv6_str( SPF_config_t spfcid, char *ipv6_address );
int	SPF_set_ipv6( SPF_config_t spfcid, struct in6_addr ipv6 );
struct in6_addr SPF_get_ipv6( SPF_config_t spfcid );

int	SPF_get_client_ver( SPF_config_t spfcid );

int	SPF_set_env_from( SPF_config_t spfcid, char *envelope_from );
char     *SPF_get_env_from( SPF_config_t spfcid );

int	SPF_set_helo_dom( SPF_config_t spfcid, char *helo_domain );
char     *SPF_get_helo_dom( SPF_config_t spfcid );

int	SPF_set_cur_dom( SPF_config_t spfcid, char *current_domain );
char	 *SPF_get_cur_dom( SPF_config_t spfcid );

SPF_err_t SPF_set_exp( SPF_config_t spfcid, char *default_exp );

int	SPF_set_max_dns_lookup( SPF_config_t spfcid, int max_dns_lookup );
int      SPF_get_max_dns_lookup( SPF_config_t spfcid );

int	SPF_set_sanitize( SPF_config_t spfcid, int sanitize );
int      SPF_get_sanitize( SPF_config_t spfcid );

int	SPF_set_rec_dom( SPF_config_t spfcid, char *receiving_hostname );
char     *SPF_get_rec_dom( SPF_config_t spfcid );

SPF_err_t SPF_compile_local_policy( SPF_config_t spfcid, char *spf_record,
				    int use_default_whitelist,
				    SPF_c_results_t *c_results );
int	SPF_set_local_policy( SPF_config_t spfcid,
			  SPF_c_results_t c_results );
SPF_err_t SPF_set_whitelist( SPF_config_t spfcid,
			     SPF_c_results_t whitelist_c_results );
SPF_id_t SPF_get_whitelist( SPF_config_t spfcid );

int	SPF_set_debug( SPF_config_t spfcid, int debug_level );
int      SPF_get_debug( SPF_config_t spfcid );



/* ********************************************************************* */

/*
 * SPF evaluation results
 */

typedef int SPF_result_t;

/* note: SPF_RESULT_* values are constrained by the internal PREFIX_* values */
#define SPF_RESULT_PASS		0	/* +				*/
#define SPF_RESULT_FAIL		1	/* -				*/
#define SPF_RESULT_SOFTFAIL	2	/* ~				*/
#define SPF_RESULT_NEUTRAL	3	/* ?				*/
#define SPF_RESULT_UNKNOWN	4	/* permanent error		*/
#define SPF_RESULT_ERROR	5	/* temp error			*/
#define SPF_RESULT_NONE		6	/* no SPF record exists		*/


typedef int SPF_reason_t;

#define SPF_REASON_NONE		0
#define SPF_REASON_LOCALHOST	1	/* localhost always gets a free ride */
#define SPF_REASON_LOCAL_POLICY	2	/* local policy caused the match */
#define SPF_REASON_MECH		3	/* mechanism caused the match	*/
#define SPF_REASON_DEFAULT	4	/* ran off the end of the rec	*/

/* FIXME  the relationships between result, reason and err is too murky */

typedef struct
{
    SPF_result_t	result;
    SPF_reason_t	reason;
    SPF_err_t		err;
    char		*err_msg;
    char		*smtp_comment;
    char		*header_comment;
    char		*received_spf;
} SPF_output_t;
    
void SPF_init_output( SPF_output_t *output );
void SPF_free_output( SPF_output_t *output );

SPF_output_t SPF_result_id( SPF_config_t spfcid, SPF_id_t spfid,
			    SPF_dns_config_t spfdcid );
SPF_output_t SPF_result( SPF_config_t spfcid, SPF_dns_config_t spfdcid,
			 char *domain );
SPF_output_t SPF_result_mx( SPF_config_t spfcid, SPF_id_t spfid,
			    SPF_dns_config_t spfdcid,
			    char *rcpt_to );
SPF_output_t SPF_result_mx_msg( SPF_config_t spfcid, SPF_id_t spfid,
				SPF_dns_config_t spfdcid );

char *SPF_strresult( SPF_result_t result );
char *SPF_strreason( SPF_reason_t reason );

SPF_err_t SPF_find_mod_value( SPF_config_t spfcid, SPF_id_t spfid,
			      SPF_dns_config_t spfdcid, char *mod_name,
			      char **buf, size_t *buf_len );
SPF_err_t SPF_find_mod_cidr( SPF_config_t spfcid, SPF_id_t spfid,
			     SPF_dns_config_t spfdcid, char *mod_name,
			     int *ipv4_cidr, int *ipv6_cidr );


/* ********************************************************************* */

/*
 * misc functions
 */

SPF_err_t SPF_id2mem( void *dst_mem, int *dst_len, SPF_id_t src_spfid );
SPF_err_t SPF_mem2id( SPF_id_t dst_spfid, void *src_mem, int src_len );

SPF_err_t SPF_id2str( char **dst_rec, size_t *dst_len, SPF_id_t src_spfid );
/* SPF_err_t SPF_str2id()   See: SPF_compile() */

void SPF_print( SPF_id_t spfid );

SPF_err_t SPF_get_spf( SPF_config_t spfcid, SPF_dns_config_t spfdcid,
		       char *domain, SPF_c_results_t *c_results );
SPF_err_t SPF_get_exp( SPF_config_t spfcid, SPF_id_t spfid,
		       SPF_dns_config_t spfdcid,
 		       char **buf, size_t *buf_len );


void SPF_set_client_dom( SPF_config_t spfcid, SPF_dns_config_t spfdcid );

char *SPF_get_client_dom( SPF_config_t spfcid, SPF_dns_config_t spfdcid );


void SPF_get_lib_version( int *major, int *minor );


void SPF_set_error( void (*error_handler)(char *file, int line, char *errmsg) __attribute__ ((noreturn)) );
#define SPF_error(errmsg) SPF_errorx( __FILE__, __LINE__, errmsg )
void SPF_errorx( char *file, int line, char *errmsg ) __attribute__ ((noreturn));

void SPF_set_warning( void (*warning_handler)(char *file, int line, char *errmsg));
#define SPF_warning(errmsg) SPF_warningx( __FILE__, __LINE__, errmsg )
void SPF_warningx( char *file, int line, char *errmsg );


#endif
