/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <string.h>


#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"
#include "spf_dns_test.h"


    
#define USE_SPF_SPEC_ZONE
#define USE_MAILZONE_ZONE

#define array_elem(x) (sizeof( x ) / sizeof( *x ))




#ifdef USE_SPF_SPEC_ZONE
/*
 * our own little zone file for example.com as used in the SPF spec
 */
static SPF_dns_rr_data_t rr_a   = { .a.s_addr = SPF_IPV4( 192,0,2,3 ) /*0x030200c0*/ }; /* 192.0.2.3 */
static SPF_dns_rr_data_t rr_mx  = { .mx  = "mx.example.org" };
static SPF_dns_rr_data_t rr_txt = { .txt = "v=spf1 mx -all" };
static SPF_dns_rr_data_t rr_ptr = { .ptr = "mx.example.org" };
#endif

#ifdef USE_MAILZONE_ZONE
/*
 * our big zone file for the mailzone.com testing subdomain
 */

static SPF_dns_rr_data_t rr_01_txt = { .txt = "v=spf1                                                             " };
static SPF_dns_rr_data_t rr_02_txt = { .txt = "v=spf1                                             -all       " };
static SPF_dns_rr_data_t rr_03_txt = { .txt = "v=spf1                                             ~all" };
static SPF_dns_rr_data_t rr_05_txt = { .txt = "v=spf1                                             default=deny   " };
static SPF_dns_rr_data_t rr_06_txt = { .txt = "v=spf1                                             ?all " };
static SPF_dns_rr_data_t rr_07_txt = { .txt = "v=spf2                                             default=bogus   " };
static SPF_dns_rr_data_t rr_08_txt = { .txt = "v=spf1                       -all      ?all  " };
static SPF_dns_rr_data_t rr_09_txt = { .txt = "v=spf1    scope=header-from scope=envelope         -all  " };
static SPF_dns_rr_data_t rr_10_txt = { .txt = "v=spf1 mx                                          -all" };
static SPF_dns_rr_data_t rr_10_mx[] = {{ .mx = "mx02.spf1-test.mailzone.com" },
				       { .mx = "mx03.spf1-test.mailzone.com" },
				       { .mx = "mx01.spf1-test.mailzone.com" }};
static SPF_dns_rr_data_t rr_11_txt = { .txt = "v=spf1    mx:spf1-test.mailzone.com                          -all" };
static SPF_dns_rr_data_t rr_12_txt = { .txt = "v=spf1 mx mx:spf1-test.mailzone.com                          -all" };
static SPF_dns_rr_data_t rr_12_mx[] = {{ .mx = "mx02.spf1-test.mailzone.com" },
				       { .mx = "mx03.spf1-test.mailzone.com" },
				       { .mx = "mx01.spf1-test.mailzone.com" }};
static SPF_dns_rr_data_t rr_13_txt = { .txt = "v=spf1    mx:spf1-test.mailzone.com mx:fallback-relay.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_14_txt = { .txt = "v=spf1 mx mx:spf1-test.mailzone.com mx:fallback-relay.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_14_mx[] = {{ .mx = "mx03.spf1-test.mailzone.com" },
				       { .mx = "mx01.spf1-test.mailzone.com" },
				       { .mx = "mx02.spf1-test.mailzone.com" }}; 
static SPF_dns_rr_data_t rr_20_a = { .a.s_addr = SPF_IPV4( 192,0,2,120 ) };
static SPF_dns_rr_data_t rr_20_txt = { .txt = "v=spf1 a                                           -all"}; 
static SPF_dns_rr_data_t rr_21_txt = { .txt = "v=spf1   a:spf1-test.mailzone.com                            -all" };
static SPF_dns_rr_data_t rr_21_a = { .a.s_addr = SPF_IPV4( 192,0,2,121 ) };
static SPF_dns_rr_data_t rr_22_txt = { .txt = "v=spf1 a a:spf1-test.mailzone.com                            -all" };
static SPF_dns_rr_data_t rr_22_a = { .a.s_addr = SPF_IPV4( 192,0,2,122 ) };
static SPF_dns_rr_data_t rr_30_txt = { .txt = "v=spf1 ptr                                         -all" };
static SPF_dns_rr_data_t rr_30_a = { .a.s_addr = SPF_IPV4( 208,210,124,130 ) };
static SPF_dns_rr_data_t rr_31_txt = { .txt = "v=spf1     ptr:spf1-test.mailzone.com                        -all" };
static SPF_dns_rr_data_t rr_31_a = { .a.s_addr = SPF_IPV4( 208,210,124,131 ) };
static SPF_dns_rr_data_t rr_32_txt = { .txt = "v=spf1 ptr ptr:spf1-test.mailzone.com                        -all" };
static SPF_dns_rr_data_t rr_32_a = { .a.s_addr = SPF_IPV4( 208,210,124,132 ) };
static SPF_dns_rr_data_t rr_40_txt = { .txt = "v=spf1 exists:%{ir}.%{v}._spf.%{d}                    -all" };
static SPF_dns_rr_data_t rr_41_txt = { .txt = "v=spf1 exists:%{ir}.%{v}._spf.spf1-test.mailzone.com            -all" };
static SPF_dns_rr_data_t rr_42_txt = { .txt = "v=spf1 exists:%{ir}.%{v}._spf.%{d} exists:%{ir}.%{v}._spf.%{d3} -all" };
static SPF_dns_rr_data_t rr_45_txt = { .txt = "v=spf1 -a a:spf1-test.mailzone.com                           -all" };
static SPF_dns_rr_data_t rr_45_a[] = {{ .a.s_addr = SPF_IPV4( 192,0,2,147 ) },
				      { .a.s_addr = SPF_IPV4( 192,0,2,145 ) },
				      { .a.s_addr = SPF_IPV4( 192,0,2,146 ) }};
static SPF_dns_rr_data_t rr_50_txt = { .txt = "v=spf1 include                                     -all" };
static SPF_dns_rr_data_t rr_51_txt = { .txt = "v=spf1 include:42.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_52_txt = { .txt = "v=spf1 include:53.spf1-test.mailzone.com                  -all" };
/* static SPF_dns_rr_data_t rr_53_CNAME = { .CNAME = "54.spf1-test.mailzone.com" }; */
static SPF_dns_rr_data_t rr_53_txt = { .txt = "v=spf1 include:42.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_54_txt = { .txt = "v=spf1 include:42.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_55_txt = { .txt = "v=spf1 include:56.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_57_txt = { .txt = "v=spf1 include:spf1-test.mailzone.com         -all" };
static SPF_dns_rr_data_t rr_58_txt = { .txt = "v=spf1 include:59.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_59_txt = { .txt = "v=spf1 include:58.spf1-test.mailzone.com                  -all" };
static SPF_dns_rr_data_t rr_70_txt = { .txt = "v=spf1 exists:%{lr+=}.lp._spf.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_80_txt = { .txt = "v=spf1 a mx exists:%{ir}.%{v}._spf.80.spf1-test.mailzone.com ptr -all" };
static SPF_dns_rr_data_t rr_80_a = { .a.s_addr = SPF_IPV4( 208,210,124,180 ) };
static SPF_dns_rr_data_t rr_90_txt = { .txt = "v=spf1  ip4:192.0.2.128/25 -all" };
static SPF_dns_rr_data_t rr_91_txt = { .txt = "v=spf1 -ip4:192.0.2.128/25 ip4:192.0.2.0/24 -all" };
static SPF_dns_rr_data_t rr_92_txt = { .txt = "v=spf1 ?ip4:192.0.2.192/26 ip4:192.0.2.128/25 -ip4:192.0.2.0/24 -all" };
static SPF_dns_rr_data_t rr_95_txt = { .txt = "v=spf1 exists:%{p}.whitelist.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_96_txt = { .txt = "v=spf1 -exists:%{d}.blacklist.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_97_txt = { .txt = "v=spf1 exists:%{p}.whitelist.spf1-test.mailzone.com -exists:%{d}.blacklist.spf1-test.mailzone.com -all" };
static SPF_dns_rr_data_t rr_98_txt = { .txt = "v=spf1 a/26 mx/26 -all" };
static SPF_dns_rr_data_t rr_98_mx = { .mx = "80.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_98_a = { .a.s_addr = SPF_IPV4( 192,0,2,98 ) };
static SPF_dns_rr_data_t rr_99_txt = { .txt = "v=spf1 -all exp=99txt.spf1-test.mailzone.com moo" };
/* static SPF_dns_rr_data_t rr_99_txt = { .txt = "v=spf1 -all exp=99txt.spf1-test.mailzone.com" }; */
static SPF_dns_rr_data_t rr_99txt_txt = { .txt = "u=%{u} s=%{s} d=%{d} t=%{t} h=%{h} i=%{i} %% U=%{U} S=%{S} D=%{D} T=%{T} H=%{H} I=%{I} %% moo" }; 
static SPF_dns_rr_data_t rr_100_txt = { .txt = "v=spf1      redirect=98.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_101_txt = { .txt = "v=spf1 -all redirect=98.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_102_txt = { .txt = "v=spf1 ?all redirect=98.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_103_txt = { .txt = "v=spf1      redirect=98.%{d3}" };
static SPF_dns_rr_data_t rr_104_txt = { .txt = "v=spf1      redirect=105.%{d3}" };
static SPF_dns_rr_data_t rr_105_txt = { .txt = "v=spf1      redirect=106.%{d3}" };
static SPF_dns_rr_data_t rr_106_txt = { .txt = "v=spf1      redirect=107.%{d3}" };
static SPF_dns_rr_data_t rr_107_txt = { .txt = "v=spf1       include:104.%{d3}" };
static SPF_dns_rr_data_t rr_110_txt = { .txt = "v=spf1 some:unrecognized=mechanism some=unrecognized:modifier -all" };
static SPF_dns_rr_data_t rr_111_txt = { .txt = "v=spf1 mx -a gpg ~all exp=111txt.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_111_mx = { .mx = "mx01.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_111_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_112_txt = { .txt = "v=spf1 a mp3 ~all" };
static SPF_dns_rr_data_t rr_112_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_113_txt = { .txt = "v=spf1 a mp3: ~all" };
static SPF_dns_rr_data_t rr_113_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_114_txt = { .txt = "v=spf1 mx -a gpg=test ~all exp=114txt.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_114_mx = { .mx = "mx01.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_114_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_115_txt = { .txt = "v=spf1 a mp3=yes -all" };
static SPF_dns_rr_data_t rr_115_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_116_txt = { .txt = "v=spf1 redirect=116rdr.spf1-test.mailzone.com a" };
static SPF_dns_rr_data_t rr_116_a = { .a.s_addr = SPF_IPV4( 192,0,2,200 ) };
static SPF_dns_rr_data_t rr_117_txt = { .txt = " v=spf1 +all" };
static SPF_dns_rr_data_t rr_118_txt = { .txt = "v=spf1 -all exp=" };

static SPF_dns_rr_data_t rr_mx01_a[] = {{ .a.s_addr = SPF_IPV4( 192,0,2,10 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,11 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,12 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,13 ) }};
static SPF_dns_rr_data_t rr_mx02_a[] = {{ .a.s_addr = SPF_IPV4( 192,0,2,20 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,21 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,22 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,23 ) }};
static SPF_dns_rr_data_t rr_mx03_a[] = {{ .a.s_addr = SPF_IPV4( 192,0,2,30 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,31 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,32 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,33 ) }};
static SPF_dns_rr_data_t rr_mx04_a[] = {{ .a.s_addr = SPF_IPV4( 192,0,2,40 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,41 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,42 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,43 ) }};
static SPF_dns_rr_data_t rr_fallback_mx = { .mx = "mx04.spf1-test.mailzone.com" };

static SPF_dns_rr_data_t rr_spf1_mx[] = {{ .mx = "mx02.spf1-test.mailzone.com" },
				       { .mx = "mx03.spf1-test.mailzone.com" },
				       { .mx = "mx01.spf1-test.mailzone.com" }};
static SPF_dns_rr_data_t rr_spf1_a[] = {{ .a.s_addr = SPF_IPV4( 208,210,124,192 ) },
					{ .a.s_addr = SPF_IPV4( 192,0,2,200 ) }};
    
static SPF_dns_rr_data_t rr_cnn_a = { .a.s_addr = SPF_IPV4( 64,236,24,4 ) };
static SPF_dns_rr_data_t rr_cnn_ptr = { .ptr = "www1.cnn.com" };
static SPF_dns_rr_data_t rr_30_ptr = { .ptr = "30.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_31_ptr = { .ptr = "31.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_spf1_ptr = { .ptr = "spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_exists_a = { .a.s_addr = SPF_IPV4( 127,0,0,2 ) };
static SPF_dns_rr_data_t rr_80_ptr = { .ptr = "80.spf1-test.mailzone.com" };
static SPF_dns_rr_data_t rr_pobox_gw_ptr = { .ptr = "pobox-gw.icgroup.com" };
static SPF_dns_rr_data_t rr_pobox_gw_a = { .a.s_addr = SPF_IPV4( 208,210,124,1 ) };
static SPF_dns_rr_data_t rr_tf_txt = { .txt = "v=spf1 exists:%{ir}.wl.trusted-forwarder.org exists:%{p}.wl.trusted-forwarder.org" };

    
#endif


static SPF_dns_rr_t SPF_dns_db[] = {
    {"localhost", ns_t_a,   1, &rr_localhost,   123, 1123, NETDB_SUCCESS,  NULL },
#ifdef USE_SPF_SPEC_ZONE
    {"example.com", ns_t_a,   1, &rr_a,   123, 1123, NETDB_SUCCESS,  NULL },
    {"example.com", ns_t_mx,  1, &rr_mx,  124, 1124, NETDB_SUCCESS,  NULL },
    {"example.com", ns_t_txt, 1, &rr_txt, 125, 1125, NETDB_SUCCESS,  NULL },
    {"3.2.0.192.in-addr.arpa", ns_t_ptr, 1, &rr_ptr, 125, 1125, NETDB_SUCCESS,  NULL },
    {"noexist.example.com", ns_t_a,   0, NULL,    123, 1123, HOST_NOT_FOUND, NULL },
    {"mx.example.org", ns_t_a,   1, &rr_a,   123, 1123, NETDB_SUCCESS,  NULL },
#endif
#ifdef USE_MAILZONE_ZONE
    { "01.spf1-test.mailzone.com", ns_t_txt, 1, &rr_01_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "02.spf1-test.mailzone.com", ns_t_txt, 1, &rr_02_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "03.spf1-test.mailzone.com", ns_t_txt, 1, &rr_03_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "05.spf1-test.mailzone.com", ns_t_txt, 1, &rr_05_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "06.spf1-test.mailzone.com", ns_t_txt, 1, &rr_06_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "07.spf1-test.mailzone.com", ns_t_txt, 1, &rr_07_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "08.spf1-test.mailzone.com", ns_t_txt, 1, &rr_08_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "09.spf1-test.mailzone.com", ns_t_txt, 1, &rr_09_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "10.spf1-test.mailzone.com", ns_t_txt, 1, &rr_10_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "10.spf1-test.mailzone.com", ns_t_mx, array_elem( rr_10_mx ), rr_10_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "11.spf1-test.mailzone.com", ns_t_txt, 1, &rr_11_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "12.spf1-test.mailzone.com", ns_t_txt, 1, &rr_12_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "12.spf1-test.mailzone.com", ns_t_mx, array_elem( rr_12_mx ), rr_12_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "13.spf1-test.mailzone.com", ns_t_txt, 1, &rr_13_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "14.spf1-test.mailzone.com", ns_t_txt, 1, &rr_14_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "14.spf1-test.mailzone.com", ns_t_mx, array_elem( rr_14_mx ), rr_14_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "20.spf1-test.mailzone.com", ns_t_a, 1, &rr_20_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "20.spf1-test.mailzone.com", ns_t_txt, 1, &rr_20_txt,  0, 0, NETDB_SUCCESS, NULL },
    { "21.spf1-test.mailzone.com", ns_t_txt, 1, &rr_21_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "21.spf1-test.mailzone.com", ns_t_a, 1, &rr_21_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "22.spf1-test.mailzone.com", ns_t_txt, 1, &rr_22_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "22.spf1-test.mailzone.com", ns_t_a, 1, &rr_22_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "30.spf1-test.mailzone.com", ns_t_txt, 1, &rr_30_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "30.spf1-test.mailzone.com", ns_t_a, 1, &rr_30_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "31.spf1-test.mailzone.com", ns_t_txt, 1, &rr_31_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "31.spf1-test.mailzone.com", ns_t_a, 1, &rr_31_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "32.spf1-test.mailzone.com", ns_t_txt, 1, &rr_32_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "32.spf1-test.mailzone.com", ns_t_a, 1, &rr_32_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "40.spf1-test.mailzone.com", ns_t_txt, 1, &rr_40_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "41.spf1-test.mailzone.com", ns_t_txt, 1, &rr_41_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "42.spf1-test.mailzone.com", ns_t_txt, 1, &rr_42_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "45.spf1-test.mailzone.com", ns_t_txt, 1, &rr_45_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "45.spf1-test.mailzone.com", ns_t_a, array_elem( rr_45_a ), rr_45_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "50.spf1-test.mailzone.com", ns_t_txt, 1, &rr_50_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "51.spf1-test.mailzone.com", ns_t_txt, 1, &rr_51_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "52.spf1-test.mailzone.com", ns_t_txt, 1, &rr_52_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "53.spf1-test.mailzone.com", ns_t_txt, 1, &rr_53_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "54.spf1-test.mailzone.com", ns_t_txt, 1, &rr_54_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "55.spf1-test.mailzone.com", ns_t_txt, 1, &rr_55_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "57.spf1-test.mailzone.com", ns_t_txt, 1, &rr_57_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "58.spf1-test.mailzone.com", ns_t_txt, 1, &rr_58_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "59.spf1-test.mailzone.com", ns_t_txt, 1, &rr_59_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "70.spf1-test.mailzone.com", ns_t_txt, 1, &rr_70_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "80.spf1-test.mailzone.com", ns_t_txt, 1, &rr_80_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "80.spf1-test.mailzone.com", ns_t_a, 1, &rr_80_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "90.spf1-test.mailzone.com", ns_t_txt, 1, &rr_90_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "91.spf1-test.mailzone.com", ns_t_txt, 1, &rr_91_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "92.spf1-test.mailzone.com", ns_t_txt, 1, &rr_92_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "95.spf1-test.mailzone.com", ns_t_txt, 1, &rr_95_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "96.spf1-test.mailzone.com", ns_t_txt, 1, &rr_96_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "97.spf1-test.mailzone.com", ns_t_txt, 1, &rr_97_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "98.spf1-test.mailzone.com", ns_t_txt, 1, &rr_98_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "98.spf1-test.mailzone.com", ns_t_mx, 1, &rr_98_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "98.spf1-test.mailzone.com", ns_t_a, 1, &rr_98_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "99.spf1-test.mailzone.com", ns_t_txt, 1, &rr_99_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "99txt.spf1-test.mailzone.com", ns_t_txt, 1, &rr_99txt_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "100.spf1-test.mailzone.com", ns_t_txt, 1, &rr_100_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "101.spf1-test.mailzone.com", ns_t_txt, 1, &rr_101_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "102.spf1-test.mailzone.com", ns_t_txt, 1, &rr_102_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "103.spf1-test.mailzone.com", ns_t_txt, 1, &rr_103_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "104.spf1-test.mailzone.com", ns_t_txt, 1, &rr_104_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "105.spf1-test.mailzone.com", ns_t_txt, 1, &rr_105_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "106.spf1-test.mailzone.com", ns_t_txt, 1, &rr_106_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "107.spf1-test.mailzone.com", ns_t_txt, 1, &rr_107_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "110.spf1-test.mailzone.com", ns_t_txt, 1, &rr_110_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "111.spf1-test.mailzone.com", ns_t_txt, 1, &rr_111_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "111.spf1-test.mailzone.com", ns_t_mx, 1, &rr_111_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "111.spf1-test.mailzone.com", ns_t_a, 1, &rr_111_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "112.spf1-test.mailzone.com", ns_t_txt, 1, &rr_112_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "112.spf1-test.mailzone.com", ns_t_a, 1, &rr_112_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "113.spf1-test.mailzone.com", ns_t_txt, 1, &rr_113_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "113.spf1-test.mailzone.com", ns_t_a, 1, &rr_113_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "114.spf1-test.mailzone.com", ns_t_txt, 1, &rr_114_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "114.spf1-test.mailzone.com", ns_t_mx, 1, &rr_114_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "114.spf1-test.mailzone.com", ns_t_a, 1, &rr_114_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "115.spf1-test.mailzone.com", ns_t_txt, 1, &rr_115_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "115.spf1-test.mailzone.com", ns_t_a, 1, &rr_115_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "116.spf1-test.mailzone.com", ns_t_txt, 1, &rr_116_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "116.spf1-test.mailzone.com", ns_t_a, 1, &rr_116_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "117.spf1-test.mailzone.com", ns_t_txt, 1, &rr_117_txt, 123, 1123, NETDB_SUCCESS, NULL },
    { "118.spf1-test.mailzone.com", ns_t_txt, 1, &rr_118_txt, 123, 1123, NETDB_SUCCESS, NULL },

    { "mx01.spf1-test.mailzone.com", ns_t_a, array_elem( rr_mx01_a ), rr_mx01_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "mx02.spf1-test.mailzone.com", ns_t_a, array_elem( rr_mx02_a ), rr_mx02_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "mx03.spf1-test.mailzone.com", ns_t_a, array_elem( rr_mx03_a ), rr_mx03_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "mx04.spf1-test.mailzone.com", ns_t_a, array_elem( rr_mx04_a ), rr_mx04_a, 123, 1123, NETDB_SUCCESS, NULL },

    { "56.spf1-test.mailzone.com", ns_t_txt, 0, NULL,  0, 0, NO_DATA, NULL },
    { "80.spf1-test.mailzone.com", ns_t_mx, 0, NULL,  0, 0, NO_DATA, NULL },
    { "servfail.spf1-test.mailzone.com", ns_t_txt, 0, NULL,  0, 0, TRY_AGAIN, NULL },
    { "spf1-test.mailzone.com", ns_t_mx, array_elem( rr_spf1_mx ), rr_spf1_mx, 123, 1123, NETDB_SUCCESS, NULL },
    { "spf1-test.mailzone.com", ns_t_a, array_elem( rr_spf1_a ), rr_spf1_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "fallback-relay.spf1-test.mailzone.com", ns_t_mx, 1, &rr_fallback_mx, 123, 1123, NETDB_SUCCESS, NULL },
    
    { "www1.cnn.com", ns_t_a, 1, &rr_cnn_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "4.24.236.64.in-addr.arpa", ns_t_ptr, 1, &rr_cnn_ptr, 123, 1123, NETDB_SUCCESS, NULL },
    { "130.124.210.208.in-addr.arpa", ns_t_ptr, 1, &rr_30_ptr, 123, 1123, NETDB_SUCCESS, NULL },
    { "131.124.210.208.in-addr.arpa", ns_t_ptr, 1, &rr_31_ptr, 123, 1123, NETDB_SUCCESS, NULL },
    { "192.124.210.208.in-addr.arpa", ns_t_ptr, 1, &rr_spf1_ptr, 123, 1123, NETDB_SUCCESS, NULL },
    { "100.2.0.192.in-addr._spf.40.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },

    { "110.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "111.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "101.2.0.192.in-addr._spf.40.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "130.2.0.192.in-addr._spf.42.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "131.2.0.192.in-addr._spf.42.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "80.2.0.192.in-addr._spf.80.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "96.spf1-test.mailzone.com.blacklist.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "97.spf1-test.mailzone.com.blacklist.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "bob.lp._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "postmaster.lp._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "1.bob.lp._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "2.bob.lp._spf.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "1.joe.lp._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "100.2.0.192.in-addr._spf.42.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "100.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "102.2.0.192.in-addr._spf.40.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "110.2.0.192.in-addr._spf.42.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "130.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "131.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "4.24.236.64.in-addr._spf.80.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "droid.lp._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "joe-2.lp._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "moe-1.lp._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "unknown.whitelist.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },

    { "180.124.210.208.in-addr.arpa", ns_t_ptr, 1, &rr_80_ptr, 123, 1123, NETDB_SUCCESS, NULL },

    { "80.spf1-test.mailzone.com.whitelist.spf1-test.mailzone.com", ns_t_a, 1, &rr_exists_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "1.124.210.208.in-addr.arpa", ns_t_ptr, 1, &rr_pobox_gw_ptr, 123, 1123, NETDB_SUCCESS, NULL },

    { "pobox-gw.icgroup.com", ns_t_a, 1, &rr_pobox_gw_a, 123, 1123, NETDB_SUCCESS, NULL },
    { "pobox-gw.icgroup.com.whitelist.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },

    { "200.2.0.192.in-addr._spf.51.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "200.2.0.192.in-addr._spf.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "130.2.0.192.in-addr._spf.51.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "200.2.0.192.in-addr._spf.42.spf1-test.mailzone.com", ns_t_a, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "spf1-test.mailzone.com", ns_t_txt, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL },
    { "spf.trusted-forwarder.org", ns_t_txt, 1, &rr_tf_txt,  0, 0, NETDB_SUCCESS, NULL },

#endif
};


static SPF_dns_rr_t *SPF_dns_lookup_test( SPF_dns_config_t spfdcid, char *domain, int rr_type, int should_cache )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    int		i;

    for( i = 0; i < array_elem( SPF_dns_db ); i++ )
    {
	if ( strcmp( SPF_dns_db[i].domain, domain ) == 0
	    && SPF_dns_db[i].rr_type == rr_type )
	    return &SPF_dns_db[i];
    }

    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->lookup( spfdic->layer_below, domain, rr_type, should_cache );
    else
	return &SPF_dns_nxdomain;
}


static int SPF_dns_cached_test( SPF_dns_config_t spfdcid, char *domain, int rr_type )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    
    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->cached( spfdic->layer_below, domain, rr_type );
    else
	return FALSE;
}


SPF_dns_config_t SPF_dns_create_config_test( SPF_dns_config_t layer_below )
{
    SPF_dns_iconfig_t     *spfdic;
    
    spfdic = malloc( sizeof( SPF_dns_iconfig_t ) );
    if ( spfdic == NULL )
	return NULL;

    spfdic->destroy  = SPF_dns_destroy_config_test;
    spfdic->lookup   = SPF_dns_lookup_test;
    spfdic->cached   = SPF_dns_cached_test;
    spfdic->get_spf  = NULL;
    spfdic->get_exp  = NULL;
    spfdic->layer_below = layer_below;
    spfdic->hook     = NULL;
    
    return SPF_spfdic2dcid( spfdic );
}

void SPF_dns_reset_config_test( SPF_dns_config_t spfdcid )
{
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );
}

void SPF_dns_destroy_config_test( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    SPF_dns_reset_config_test( spfdcid );

    if ( spfdic->hook )
	free( spfdic->hook );
    free( spfdic );
}
