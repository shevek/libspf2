/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"


/*
 * helper functions
 */

void SPF_dns_destroy_config( SPF_dns_config_t spfdcid )
{
    SPF_dcid2spfdic( spfdcid )->destroy( spfdcid );
}

SPF_dns_rr_t *SPF_dns_lookup( SPF_dns_config_t spfdcid,
			      char *domain, ns_type rr_type, int should_cache )
{
    return SPF_dcid2spfdic( spfdcid )->lookup( spfdcid, domain, rr_type, should_cache );
}

int SPF_dns_cached( SPF_dns_config_t spfdcid,
			       char *domain, ns_type rr_type )
{
    if ( SPF_dcid2spfdic( spfdcid )->cached == NULL )
	return FALSE;
    
    return SPF_dcid2spfdic( spfdcid )->cached( spfdcid, domain, rr_type );
}

SPF_dns_rr_t *SPF_dns_rlookup( SPF_dns_config_t spfdcid,
			       struct in_addr ipv4, ns_type rr_type, int should_cache )
{

    /* FIXME  WTF aren't I using inet_ntop??? */

    union
    {
	struct in_addr	ipv4;
	unsigned char	x[4];
    } tmp;

    char	domain[ sizeof( "111.222.333.444.in-addr.arpa" ) ];
    
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    /*
     * make sure the scratch buffer is big enough
     */
    tmp.ipv4 = ipv4;

    SPF_snprintf( domain, sizeof( domain ), "%d.%d.%d.%d.in-addr.arpa",
	     tmp.x[3], tmp.x[2], tmp.x[1], tmp.x[0] );


    return SPF_dcid2spfdic( spfdcid )->lookup( spfdcid, domain, rr_type, should_cache );
}


SPF_dns_rr_t *SPF_dns_rlookup6( SPF_dns_config_t spfdcid,
				struct in6_addr ipv6, ns_type rr_type, int should_cache )
{
    /* FIXME  WTF aren't I using inet_ntop??? */

    union
    {
	struct in6_addr	ipv6;
	unsigned char	x[16];
    } tmp;

    /* FIXME  I'm not sure of the format for ipv6 in-addr's */
    char	domain[ sizeof( "111.222.333.444.in-addr.arpa" ) ];
    
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    tmp.ipv6 = ipv6;

    SPF_snprintf( domain, sizeof( domain ), "%d.%d.%d.%d.in-addr.arpa",
	     tmp.x[3], tmp.x[2], tmp.x[1], tmp.x[0] );

    return SPF_dcid2spfdic( spfdcid )->lookup( spfdcid, domain, rr_type, should_cache );
}



int SPF_dns_rcached( SPF_dns_config_t spfdcid,
		     struct in_addr ipv4, ns_type rr_type )
{
    /* FIXME  WTF aren't I using inet_ntop??? */

    union
    {
	struct in_addr	ipv4;
	unsigned char	x[4];
    } tmp;

    char	domain[ sizeof( "111.222.333.444.in-addr.arpa" ) ];
    
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    tmp.ipv4 = ipv4;

    SPF_snprintf( domain, sizeof( domain ), "%d.%d.%d.%d.in-addr.arpa",
	     tmp.x[3], tmp.x[2], tmp.x[1], tmp.x[0] );


    return SPF_dcid2spfdic( spfdcid )->cached( spfdcid, domain, rr_type );
}


int SPF_dns_rcached6( SPF_dns_config_t spfdcid,
		      struct in6_addr ipv6, ns_type rr_type )
{
    /* FIXME  WTF aren't I using inet_ntop??? */

    union
    {
	struct in6_addr	ipv6;
	unsigned char	x[16];
    } tmp;

    /* FIXME  I'm not sure of the format for ipv6 in-addr's */
    char	domain[ sizeof( "111.222.333.444.in-addr.arpa" ) ];
    
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    /*
     * make sure the scratch buffer is big enough
     */
    tmp.ipv6 = ipv6;

    SPF_snprintf( domain, sizeof( domain ), "%d.%d.%d.%d.in-addr.arpa",
	     tmp.x[3], tmp.x[2], tmp.x[1], tmp.x[0] );

    return SPF_dcid2spfdic( spfdcid )->cached( spfdcid, domain, rr_type );
}



SPF_dns_rr_t *SPF_dns_make_rr( char *domain, ns_type rr_type,
			       int ttl, SPF_dns_stat_t herrno )
{
    SPF_dns_rr_t	*spfrr;

    spfrr = SPF_dns_create_rr();
    if ( spfrr == NULL )
	return spfrr;

    spfrr->domain = strdup( domain );
    spfrr->rr_type = rr_type;
    spfrr->ttl = ttl;
    spfrr->herrno = herrno;

    return spfrr;
}


SPF_dns_rr_t *SPF_dns_create_rr()
{
    SPF_dns_rr_t	*spfrr;

    spfrr = malloc( sizeof( *spfrr ) );
    if ( spfrr == NULL )
	return spfrr;

    memset( spfrr, 0, sizeof( *spfrr ) );
    
    SPF_dns_reset_rr( spfrr );
    return spfrr;
}


void SPF_dns_reset_rr( SPF_dns_rr_t *spfrr )
{
    int		i;

    if ( spfrr == NULL )
	return;
    

    if ( spfrr->domain ) free( spfrr->domain );

    if ( spfrr->rr )
    {
	for ( i = 0; i < spfrr->num_rr; i++ )
	{

	    switch( spfrr->rr_type )
	    {
	    case ns_t_mx:
		if ( spfrr->rr[i].mx ) free( spfrr->rr[i].mx );
		break;
		
	    case ns_t_txt:
		if ( spfrr->rr[i].txt ) free( spfrr->rr[i].txt );
		break;
		
	    case ns_t_ptr:
		if ( spfrr->rr[i].ptr ) free( spfrr->rr[i].ptr );
		break;
	    }		    
	}
	free( spfrr->rr );
    }

    memset( spfrr, 0, sizeof( *spfrr ) );
    spfrr->rr_type = ns_t_invalid;
    spfrr->herrno = HOST_NOT_FOUND;
}


    

SPF_dns_rr_t *SPF_dns_dup_rr( SPF_dns_rr_t *orig )
{
    SPF_dns_rr_t	*spfrr;
    int			i;
    

    if ( orig == NULL )
	return NULL;

    spfrr = malloc( sizeof( *spfrr ) );
    if ( spfrr == NULL )
	return spfrr;

    *spfrr = *orig;

    if ( spfrr->domain )
    {
	spfrr->domain = strdup( spfrr->domain );
		
	if ( spfrr->domain == NULL )
	{
	    free( spfrr );
	    return NULL;
	}
    }
    

    if ( spfrr->num_rr )
    {
	spfrr->rr = malloc( spfrr->num_rr * sizeof( *spfrr->rr ) );
	if ( spfrr->rr == NULL )
	{
	    if ( spfrr->domain ) free( spfrr->domain );
	    free( spfrr );
	    return NULL;
	}
	memcpy( spfrr->rr, orig->rr, spfrr->num_rr * sizeof( *spfrr->rr ) );
	
	for ( i = 0; i < spfrr->num_rr; i++ )
	{
	    switch( spfrr->rr_type )
	    {
	    case ns_t_mx:
		spfrr->rr[i].mx = strdup( spfrr->rr[i].mx );
		break;
		
	    case ns_t_txt:
		spfrr->rr[i].txt = strdup( spfrr->rr[i].txt );
		break;
		
	    case ns_t_ptr:
		spfrr->rr[i].ptr = strdup( spfrr->rr[i].ptr );
		break;
		
	    default:
		break;
	    }
	}		    
    }

    return spfrr;
}

void SPF_dns_destroy_rr( SPF_dns_rr_t *spfrr )
{
    SPF_dns_reset_rr( spfrr );
    free( spfrr );
}



/*
 * Set the SMPT client domain name
 */

void SPF_set_client_dom( SPF_config_t spfcid, SPF_dns_config_t spfdcid )
{
    SPF_iconfig_t *spfic = SPF_cid2spfic(spfcid);
    SPF_dns_rr_t *rr_ptr;
    SPF_dns_rr_t *rr_a;
    SPF_dns_rr_t *rr_a6;
    
    int		i, j;
    

    if ( spfcid == NULL )
	SPF_error( "spfcid is null" );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );


    if ( spfic->client_dom )
	return;
    
/*
 * The "p" macro expands to the validated domain name of the SMTP
 * client.  The validation procedure is described in section 5.4.  If
 * there are no validated domain names, the word "unknown" is
 * substituted.  If multiple validated domain names exist, the first one
 * returned in the PTR result is chosen.
 *
 *
 *   sending-host_names := ptr_lookup(sending-host_IP);
 *   for each name in (sending-host_names) {
 *     IP_addresses := a_lookup(name);
 *     if the sending-host_IP is one of the IP_addresses {
 *       validated_sending-host_names += name;
 *   } }
 */

    if ( spfic->client_ver == AF_INET )
    {
	rr_ptr = SPF_dns_dup_rr( SPF_dns_rlookup( spfdcid, spfic->ipv4, ns_t_ptr, FALSE ) );
	if ( rr_ptr == NULL )
	    SPF_error( "SPF_dns_rlookup return NULL" );
    
	for( i = 0; i < rr_ptr->num_rr; i++ )
	{
	    rr_a = SPF_dns_lookup( spfdcid, rr_ptr->rr[i].ptr, ns_t_a, FALSE );
	    if ( rr_a == NULL )
		SPF_error( "SPF_dns_lookup return NULL" );

	    for( j = 0; j < rr_a->num_rr; j++ )
	    {
		if ( rr_a->rr[j].a.s_addr == spfic->ipv4.s_addr )
		{
		    spfic->client_dom = strdup( rr_ptr->rr[i].ptr );
		    SPF_dns_destroy_rr( rr_ptr );
		    return;
		}
	    }
	}
	SPF_dns_destroy_rr( rr_ptr );
    }
	    
    else if ( spfic->client_ver == AF_INET6 )
    {
	rr_ptr = SPF_dns_dup_rr( SPF_dns_rlookup6( spfdcid, spfic->ipv6, ns_t_ptr, FALSE ) );

	if ( rr_ptr == NULL )
	    SPF_error( "SPF_dns_rlookup return NULL" );
    
	for( i = 0; i < rr_ptr->num_rr; i++ )
	{
	    rr_a6 = SPF_dns_lookup( spfdcid, rr_ptr->rr[i].ptr, ns_t_a6, FALSE );
	    if ( rr_a6 == NULL )
		SPF_error( "SPF_dns_lookup return NULL" );

	    for( j = 0; j < rr_a6->num_rr; j++ )
	    {
		if ( memcmp( rr_a6->rr[j].a6.in6_u.u6_addr8,
			     spfic->ipv6.in6_u.u6_addr8,
			     sizeof( spfic->ipv6.in6_u.u6_addr8 ) ) == 0 )
		{
		    spfic->client_dom = strdup( rr_ptr->rr[i].ptr );
		    SPF_dns_destroy_rr( rr_ptr );
		    return;
		}
	    }
	}
	SPF_dns_destroy_rr( rr_ptr );
    }

    spfic->client_dom = strdup( "unknown" );
}



SPF_dns_rr_t SPF_dns_nxdomain = 
    {"", ns_t_invalid, 0, NULL,  0, 0, HOST_NOT_FOUND, NULL };


SPF_dns_rr_data_t rr_localhost   = { .a.s_addr = SPF_IPV4( 127,0,0,1 ) };

