/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */




#ifndef INC_SPF_DNS_INTERNAL
#define INC_SPF_DNS_INTERNAL




typedef union
{
    char		*txt;
    char		*mx;
    struct in_addr	a;
    struct in6_addr	a6;
    char		*ptr;
} SPF_dns_rr_data_t;
    

typedef struct
{
    char		*domain;
    ns_type		rr_type;
    int			num_rr;
    SPF_dns_rr_data_t	*rr;
    int			ttl;
    time_t		utc_ttl;
    SPF_dns_stat_t	herrno;

    void		*hook;
} SPF_dns_rr_t;




/*
 * You do not need to free RR info that have been returned by the lookup
 * functions, just ones that you create or dup
 */
SPF_dns_rr_t *SPF_dns_make_rr( char *domain, ns_type rr_type,
			       int ttl, SPF_dns_stat_t herrno );
SPF_dns_rr_t *SPF_dns_create_rr();
void SPF_dns_reset_rr( SPF_dns_rr_t *spfrr );
SPF_dns_rr_t *SPF_dns_dup_rr( SPF_dns_rr_t *orig );
void SPF_dns_destroy_rr( SPF_dns_rr_t *spfrr );


/*
 * These lookup functions just return pointers to an internal structure.
 * The pointers become invalid as soon as the next lookup function is
 * called because the structure may be reused.
 *
 * If you need to know about more than one RR at a time, you can duplicate
 * the entry and then free it when you are done.  
 */

SPF_dns_rr_t *SPF_dns_lookup( SPF_dns_config_t spfdcid,
			      char *domain, ns_type rr_type, int should_cache );
SPF_dns_rr_t *SPF_dns_rlookup( SPF_dns_config_t spfdcid,
			       struct in_addr ipv4, ns_type rr_type, int should_cache );
SPF_dns_rr_t *SPF_dns_rlookup6( SPF_dns_config_t spfdcid,
				struct in6_addr ipv6, ns_type rr_type, int should_cache );



typedef void (*SPF_dns_destroy_t)( SPF_dns_config_t spfdcid );
typedef SPF_dns_rr_t *(*SPF_dns_lookup_t)( SPF_dns_config_t spfdcid, char *domain, int ns_type, int should_cache );
typedef int (*SPF_dns_cached_t)( SPF_dns_config_t spfdcid, char *domain, int ns_type );

typedef SPF_err_t (*SPF_dns_get_spf_t)( SPF_config_t spfcid, SPF_dns_config_t spfdcid, char *domain, SPF_c_results_t *c_results );
typedef SPF_err_t (*SPF_dns_get_exp_t)( SPF_config_t spfcid, 
					SPF_dns_config_t spfdcid, char *domain,
					char **buf, size_t *buf_len );


typedef struct SPF_dns_iconfig_struct
{
    SPF_dns_destroy_t	destroy;

    /* functions that all DNS layers must implement */
    SPF_dns_lookup_t	lookup;
    SPF_dns_cached_t	cached;

    /* functions that all DNS layers may implement (null if not implemented) */
    SPF_dns_get_spf_t	get_spf;
    SPF_dns_get_exp_t	get_exp;

    /* the next DNS layer down to call if this layer can't give an answer */
    SPF_dns_config_t	layer_below;

    void	*hook;
} SPF_dns_iconfig_t;


static inline SPF_dns_iconfig_t *SPF_dcid2spfdic( SPF_dns_config_t spfdcid ) 
    { return (SPF_dns_iconfig_t *)spfdcid; }
static inline SPF_dns_config_t SPF_spfdic2dcid( SPF_dns_iconfig_t *spfdic ) 
    { return (SPF_dns_config_t)spfdic; }


extern SPF_dns_rr_t SPF_dns_nxdomain;
extern SPF_dns_rr_data_t rr_localhost;


#endif
