/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>


#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"
#include "spf_dns_null.h"


typedef struct
{
    int		debug;
} SPF_dns_null_config_t; 


static inline SPF_dns_null_config_t *SPF_voidp2spfhook( void *hook ) 
    { return (SPF_dns_null_config_t *)hook; }
static inline void *SPF_spfhook2voidp( SPF_dns_null_config_t *spfhook ) 
    { return (void *)spfhook; }



static SPF_dns_rr_t *SPF_dns_lookup_null( SPF_dns_config_t spfdcid, char *domain, int rr_type, int should_cache )
{
    SPF_dns_iconfig_t		*spfdic = SPF_dcid2spfdic( spfdcid );
    SPF_dns_null_config_t	*spfhook = SPF_voidp2spfhook( spfdic->hook );

    if ( spfhook->debug )
	fprintf( stderr, "DNS lookup:  %s  %s (%d)\n",
		 domain,
		 ( (rr_type == ns_t_a)   ? "A" :
		   (rr_type == ns_t_mx)  ? "MX" :
		   (rr_type == ns_t_txt) ? "TXT" :
		   (rr_type == ns_t_ptr) ? "PTR" :
		   "??" ),
		 rr_type );

    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->lookup( spfdic->layer_below, domain, rr_type, should_cache );
    else
	return &SPF_dns_nxdomain;

}


static int SPF_dns_cached_null( SPF_dns_config_t spfdcid, char *domain, int rr_type )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    
    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->cached( spfdic->layer_below, domain, rr_type );
    else
	return FALSE;
}



SPF_dns_config_t SPF_dns_create_config_null( SPF_dns_config_t layer_below, int debug )
{
    SPF_dns_iconfig_t     *spfdic;
    SPF_dns_null_config_t *spfhook;
    
    spfdic = malloc( sizeof( *spfdic ) );
    if ( spfdic == NULL )
	return NULL;

    spfdic->hook = malloc( sizeof( SPF_dns_null_config_t ) );
    if ( spfdic->hook == NULL )
    {
	free( spfdic );
	return NULL;
    }
    
    spfdic->destroy  = SPF_dns_destroy_config_null;
    spfdic->lookup   = SPF_dns_lookup_null;
    spfdic->cached   = SPF_dns_cached_null;
    spfdic->get_spf  = NULL;
    spfdic->get_exp  = NULL;
    spfdic->layer_below = layer_below;
    
    spfhook = SPF_voidp2spfhook( spfdic->hook );
    spfhook->debug = debug;

    return SPF_spfdic2dcid( spfdic );
}

void SPF_dns_reset_config_null( SPF_dns_config_t spfdcid )
{
    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );
}

void SPF_dns_destroy_config_null( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    SPF_dns_reset_config_null( spfdcid );

    if ( spfdic->hook )
	free( spfdic->hook );
    if ( spfdic )
	free( spfdic );
}
