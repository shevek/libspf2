/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version,
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */



#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "spf.h"
#include "spf_internal.h"




void SPF_print( SPF_id_t spfid )
{
    SPF_internal_t *spfi = SPF_id2spfi(spfid);
    char	*prt_buf = NULL;
    size_t	prt_len = 0;

    int		err;

    /*
     * make sure we were passed valid data to work with
     */
    if ( spfi == NULL )
	SPF_error( "spfid is NULL" );
    
    printf( "SPF header:  version: %d  mech %d/%d  mod %d/%d  len=%d\n",
	    spfi->header.version,
	    spfi->header.num_mech, spfi->header.mech_len, 
	    spfi->header.num_mod, spfi->header.mod_len,
	    sizeof(spfi->header) + spfi->header.mech_len
	    + spfi->header.mod_len);

    err = SPF_id2str( &prt_buf, &prt_len, spfid );
    if ( err == SPF_E_RESULT_UNKNOWN )
	printf( "Unknown\n" );
    else if ( err )
	printf( "SPF_id2str error: %s (%d)\n", SPF_strerror( err ), err );
    else
	printf( "SPF record:  %s\n", prt_buf );

    if ( prt_buf )
	free( prt_buf );
	    
}





void SPF_print_sizeof()
{
    printf( "sizeof(SPF_rec_header_t)=%u\n", sizeof(SPF_rec_header_t));
    printf( "sizeof(SPF_mech_t)=%u\n", sizeof(SPF_mech_t));
    printf( "sizeof(SPF_data_t)=%u\n", sizeof(SPF_data_t));
    printf( "sizeof(SPF_mod_t)=%u\n", sizeof(SPF_mod_t));
}
