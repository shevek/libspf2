/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <time.h>


#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"
#include "spf_dns_cache.h"


/*
 * this is really little more than a proof-of-concept cache.
 *
 * The cache size is limited to 64k DNS entries due to using the
 * CRC-16 function as a hash generator.  Nothing is done about hash
 * collisions, no alternate hash functions, no buckets, no linked
 * lists, no reclaim list, nothing. (The CRC-16 function was chosen
 * because I had a copy handy, it is pretty fast, and single bit
 * changes are guarenteed to give a different hash.  So, mx1.foo.com
 * and mx2.foo.com will not collide)
 */


typedef struct
{
    SPF_dns_rr_t	**cache;
    int			cache_size;
    int			hash_mask;
} SPF_dns_cache_config_t; 



/* FXIME  this isn't used.  shouldn't we use c_results anyway? */
typedef struct 
{
    int			hash;

    SPF_id_t		spfid;
    SPF_id_t		spfid_optimized;
    time_t		opt_utc_ttl;

    SPF_id_t		exp_id;
} SPF_dns_cache_data_t;
    


static inline SPF_dns_cache_config_t *SPF_voidp2spfhook( void *hook ) 
    { return (SPF_dns_cache_config_t *)hook; }
static inline void *SPF_spfhook2voidp( SPF_dns_cache_config_t *spfhook ) 
    { return (void *)spfhook; }


/*
** calculate CRC-16 stuff.
*/

static unsigned short crc_16_tab[256] = {
    0x0000,  0x1021,  0x2042,  0x3063,  0x4084,  0x50a5,  0x60c6,  0x70e7,
    0x8108,  0x9129,  0xa14a,  0xb16b,  0xc18c,  0xd1ad,  0xe1ce,  0xf1ef,
    0x1231,  0x0210,  0x3273,  0x2252,  0x52b5,  0x4294,  0x72f7,  0x62d6,
    0x9339,  0x8318,  0xb37b,  0xa35a,  0xd3bd,  0xc39c,  0xf3ff,  0xe3de,
    0x2462,  0x3443,  0x0420,  0x1401,  0x64e6,  0x74c7,  0x44a4,  0x5485,
    0xa56a,  0xb54b,  0x8528,  0x9509,  0xe5ee,  0xf5cf,  0xc5ac,  0xd58d,
    0x3653,  0x2672,  0x1611,  0x0630,  0x76d7,  0x66f6,  0x5695,  0x46b4,
    0xb75b,  0xa77a,  0x9719,  0x8738,  0xf7df,  0xe7fe,  0xd79d,  0xc7bc,
    0x48c4,  0x58e5,  0x6886,  0x78a7,  0x0840,  0x1861,  0x2802,  0x3823,
    0xc9cc,  0xd9ed,  0xe98e,  0xf9af,  0x8948,  0x9969,  0xa90a,  0xb92b,
    0x5af5,  0x4ad4,  0x7ab7,  0x6a96,  0x1a71,  0x0a50,  0x3a33,  0x2a12,
    0xdbfd,  0xcbdc,  0xfbbf,  0xeb9e,  0x9b79,  0x8b58,  0xbb3b,  0xab1a,
    0x6ca6,  0x7c87,  0x4ce4,  0x5cc5,  0x2c22,  0x3c03,  0x0c60,  0x1c41,
    0xedae,  0xfd8f,  0xcdec,  0xddcd,  0xad2a,  0xbd0b,  0x8d68,  0x9d49,
    0x7e97,  0x6eb6,  0x5ed5,  0x4ef4,  0x3e13,  0x2e32,  0x1e51,  0x0e70,
    0xff9f,  0xefbe,  0xdfdd,  0xcffc,  0xbf1b,  0xaf3a,  0x9f59,  0x8f78,
    0x9188,  0x81a9,  0xb1ca,  0xa1eb,  0xd10c,  0xc12d,  0xf14e,  0xe16f,
    0x1080,  0x00a1,  0x30c2,  0x20e3,  0x5004,  0x4025,  0x7046,  0x6067,
    0x83b9,  0x9398,  0xa3fb,  0xb3da,  0xc33d,  0xd31c,  0xe37f,  0xf35e,
    0x02b1,  0x1290,  0x22f3,  0x32d2,  0x4235,  0x5214,  0x6277,  0x7256,
    0xb5ea,  0xa5cb,  0x95a8,  0x8589,  0xf56e,  0xe54f,  0xd52c,  0xc50d,
    0x34e2,  0x24c3,  0x14a0,  0x0481,  0x7466,  0x6447,  0x5424,  0x4405,
    0xa7db,  0xb7fa,  0x8799,  0x97b8,  0xe75f,  0xf77e,  0xc71d,  0xd73c,
    0x26d3,  0x36f2,  0x0691,  0x16b0,  0x6657,  0x7676,  0x4615,  0x5634,
    0xd94c,  0xc96d,  0xf90e,  0xe92f,  0x99c8,  0x89e9,  0xb98a,  0xa9ab,
    0x5844,  0x4865,  0x7806,  0x6827,  0x18c0,  0x08e1,  0x3882,  0x28a3,
    0xcb7d,  0xdb5c,  0xeb3f,  0xfb1e,  0x8bf9,  0x9bd8,  0xabbb,  0xbb9a,
    0x4a75,  0x5a54,  0x6a37,  0x7a16,  0x0af1,  0x1ad0,  0x2ab3,  0x3a92,
    0xfd2e,  0xed0f,  0xdd6c,  0xcd4d,  0xbdaa,  0xad8b,  0x9de8,  0x8dc9,
    0x7c26,  0x6c07,  0x5c64,  0x4c45,  0x3ca2,  0x2c83,  0x1ce0,  0x0cc1,
    0xef1f,  0xff3e,  0xcf5d,  0xdf7c,  0xaf9b,  0xbfba,  0x8fd9,  0x9ff8,
    0x6e17,  0x7e36,  0x4e55,  0x5e74,  0x2e93,  0x3eb2,  0x0ed1,  0x1ef0
};

static int inline crc16str(unsigned short accum, char *str )
{
    char	*str_end = str + 16;

    for( ; *str != '\0' && str != str_end; str++ )
	accum = crc_16_tab[ (unsigned char)accum ^ (unsigned char)*str ]
	    ^ (unsigned char)(accum >> 8);

   return(accum);
}

#define hash(h,s,a) (crc16str(a,s) & (h->hash_mask))


static SPF_dns_rr_t *SPF_dns_lookup_cache( SPF_dns_config_t spfdcid, char *domain, int rr_type, int should_cache )
{
    SPF_dns_iconfig_t		*spfdic = SPF_dcid2spfdic( spfdcid );
    SPF_dns_cache_config_t	*spfhook = SPF_voidp2spfhook( spfdic->hook );

    SPF_dns_rr_t	*cached_rr, *fetched_rr;
    int			h = hash( spfhook, domain, spfhook->cache_size );
    time_t		t = 0;

    cached_rr = spfhook->cache[ h ];
    
    if ( cached_rr
	 && cached_rr->domain
	 && cached_rr->rr_type == rr_type
	 && strcmp( cached_rr->domain, domain ) == 0
	 && cached_rr->utc_ttl < (t = time( NULL )))
	return cached_rr;

    if ( spfdic->layer_below )
	fetched_rr = SPF_dcid2spfdic( spfdic->layer_below )->lookup( spfdic->layer_below, domain, rr_type, should_cache );
    else
	return &SPF_dns_nxdomain;

    if ( !should_cache )
	return fetched_rr;

    cached_rr = SPF_dns_dup_rr( fetched_rr );
    if ( cached_rr == NULL )
	return fetched_rr;
    
    if ( t == 0 ) t = time( NULL );
    cached_rr->utc_ttl = cached_rr->ttl + t;
    if ( spfhook->cache[ h ] ) SPF_dns_destroy_rr( spfhook->cache[ h ] );
    spfhook->cache[ h ] = cached_rr;
    
    return cached_rr;
}


static int SPF_dns_cached_cache( SPF_dns_config_t spfdcid, char *domain, int rr_type )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    
    /* FIXME  we need to check the cache here! */


    if ( spfdic->layer_below )
	return SPF_dcid2spfdic( spfdic->layer_below )->cached( spfdic->layer_below, domain, rr_type );
    else
	return FALSE;
}



SPF_dns_config_t SPF_dns_create_config_cache( SPF_dns_config_t layer_below, int cache_bits )
{
    SPF_dns_iconfig_t     *spfdic;
    SPF_dns_cache_config_t *spfhook;
    
    if ( layer_below == NULL )
	SPF_error( "layer_below is null." );

    if ( cache_bits < 1 || cache_bits > 16 )
	SPF_error( "cache bits out of range (1..16)." );
    

    spfdic = malloc( sizeof( *spfdic ) );
    if ( spfdic == NULL )
	return NULL;

    spfdic->hook = malloc( sizeof( SPF_dns_cache_config_t ) );
    if ( spfdic->hook == NULL )
    {
	free( spfdic );
	return NULL;
    }
    
    spfdic->destroy   = SPF_dns_destroy_config_cache;
    spfdic->lookup   = SPF_dns_lookup_cache;
    spfdic->cached   = SPF_dns_cached_cache;
#if 0
    /* FIXME  need to do more than just cache DNS records */
    spfdic->get_spf  = SPF_dns_get_spf_cache;
    spfdic->get_exp  = SPF_dns_get_exp_cache;
#else
    spfdic->get_spf  = NULL;
    spfdic->get_exp  = NULL;
#endif
    spfdic->layer_below = layer_below;
    
    spfhook = SPF_voidp2spfhook( spfdic->hook );

    spfhook->cache_size = 1 << cache_bits;
    spfhook->hash_mask = spfhook->cache_size - 1;
    spfhook->cache = malloc( spfhook->cache_size * sizeof( *spfhook->cache ) );
    memset( spfhook->cache, 0, spfhook->cache_size * sizeof( *spfhook->cache ) );


    if ( spfhook->cache == NULL )
    {
	free( spfdic );
	return NULL;
    }
    
    return SPF_spfdic2dcid( spfdic );
}

void SPF_dns_reset_config_cache( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t		*spfdic = SPF_dcid2spfdic( spfdcid );
    SPF_dns_cache_config_t	*spfhook = SPF_voidp2spfhook( spfdic->hook );
    int			i;

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    if ( spfhook == NULL )
	SPF_error( "spfdcid.hook is null" );
	
    if ( spfhook->cache == NULL )
	SPF_error( "spfdcid.hook->cache is null" );
	
    for( i = 0; i < spfhook->cache_size; i++ )
    {
	if ( spfhook->cache[i] )
	    SPF_dns_destroy_rr( spfhook->cache[i] );
	spfhook->cache[i] = NULL;
    }
}


void SPF_dns_destroy_config_cache( SPF_dns_config_t spfdcid )
{
    SPF_dns_iconfig_t     *spfdic = SPF_dcid2spfdic( spfdcid );
    SPF_dns_cache_config_t	*spfhook = SPF_voidp2spfhook( spfdic->hook );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );

    SPF_dns_reset_config_cache( spfdcid );

	    
    if ( spfhook )
    {
	if ( spfhook->cache ) free( spfhook->cache );
	free( spfhook );
    }
    
    free( spfdic );
}

