/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either:
 * 
 *   a) The GNU Lesser General Public License as published by the Free
 *      Software Foundation; either version 2.1, or (at your option) any
 *      later version, 
 * 
 *   OR
 * 
 *   b) The two-clause BSD license.
 *
 * These licenses can be found with the distribution in the file LICENSES
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "spf.h"
#include "spf_dns.h"
#include "spf_internal.h"
#include "spf_dns_internal.h"


int SPF_mech_cidr( SPF_config_t spfcid, SPF_mech_t *mech )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);
    SPF_data_t		*data;
    
    if ( spfcid == NULL )
	SPF_error( "spfcid is null" );
    
    if ( mech == NULL )
	SPF_error( "mech is null" );
    
    switch( mech->mech_type )
    {
    case MECH_IP4:
    case MECH_IP6:
	return mech->parm_len;
	break;

    case MECH_A:
    case MECH_MX:
	data = SPF_mech_data( mech );
	if ( data->dc.parm_type == PARM_CIDR )
	{
	    if ( spfic->client_ver == AF_INET )
		return data->dc.ipv4;
	    else if ( spfic->client_ver == AF_INET6 )
		return data->dc.ipv6;
	}
	break;
    }
	
    return 0;
}



int SPF_ip_match( SPF_config_t spfcid, SPF_mech_t *mech,
		  struct in_addr ipv4 )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);

    char	src_ip4_buf[ INET_ADDRSTRLEN ];
    char	dst_ip4_buf[ INET_ADDRSTRLEN ];

    const char	*p_err;


    struct in_addr	src_ipv4 = spfic->ipv4;
    int		cidr, mask;
	

    if ( spfic->client_ver != AF_INET )
	return FALSE;


    cidr = SPF_mech_cidr( spfcid, mech );
    if ( cidr == 0 )
	cidr = 32;
    mask = 0xffffffff << (32 - cidr);
    mask = htonl( mask );
	
    if ( spfic->debug )
    {
	p_err = inet_ntop( AF_INET, &src_ipv4.s_addr,
			   src_ip4_buf, sizeof( src_ip4_buf ) );
	if ( p_err == NULL )
	    SPF_snprintf( src_ip4_buf, sizeof( src_ip4_buf ), "ip-error" );

	p_err = inet_ntop( AF_INET, &ipv4.s_addr,
			   dst_ip4_buf, sizeof( dst_ip4_buf ) );
	if ( p_err == NULL )
	    SPF_snprintf( dst_ip4_buf, sizeof( dst_ip4_buf ), "ip-error" );

	printf( "ip_match:  %s == %s  (/%d %08x):  %d\n",
		src_ip4_buf, dst_ip4_buf, cidr, ntohl( mask ), 
		(src_ipv4.s_addr & mask) == (ipv4.s_addr & mask));
    }

    return (src_ipv4.s_addr & mask) == (ipv4.s_addr & mask);
}


int SPF_ip_match6( SPF_config_t spfcid, SPF_mech_t *mech,
		   struct in6_addr ipv6 )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);

#if 0
    char	src_ip6_buf[ INET6_ADDRSTRLEN ];
    char	dst_ip6_buf[ INET6_ADDRSTRLEN ];

    const char	*p_err;
#endif


    if ( spfic->client_ver != AF_INET6 )
	return FALSE;

    /* FIXME  ipv6 */

    return FALSE;
}


SPF_output_t SPF_eval_id( SPF_config_t spfcid, SPF_id_t spfid,
			    SPF_dns_config_t spfdcid,
			    int *num_dns_mech, int use_local_policy )
{
    SPF_iconfig_t	*spfic = SPF_cid2spfic(spfcid);
    SPF_internal_t	*spfi = SPF_id2spfi(spfid);
    SPF_output_t	output;

    int		i, j;
    int		m;
    SPF_mech_t	*mech;
    SPF_mech_t	*local_policy;
    int		found_all;
    SPF_data_t	*data;

    char	*buf = NULL;
    size_t	buf_len = 0;
    ns_type	fetch_ns_type;
    char	*lookup;

    SPF_dns_rr_t *rr_a;
    SPF_dns_rr_t *rr_a6;
    SPF_dns_rr_t *rr_ptr;
    SPF_dns_rr_t *rr_mx;

    SPF_err_t	err;

    char	*sender_dom, *sd, *cd;
    
    char	*pc, *ps;

    SPF_c_results_t c_results;

    SPF_output_t	inc_out;

    char	*save_cur_dom;
    int		local_num_dns_mech;
    

    /*
     * make sure we were passed valid data to work with
     */
    if ( spfic == NULL )
	SPF_error( "spfcid is null" );

    if ( spfi == NULL )
	SPF_error( "spfid is NULL" );

    if ( spfdcid == NULL )
	SPF_error( "spfdcid is null" );


    if ( spfic->debug > 0 )
	SPF_print( spfid );


    if ( num_dns_mech == NULL )
    {
	local_num_dns_mech = 0;
	num_dns_mech = &local_num_dns_mech;
    }
    

    SPF_init_c_results( &c_results );

    SPF_init_output( &output );
    
    output.result = SPF_RESULT_PASS;
    output.reason = SPF_REASON_NONE;
    output.err = SPF_E_SUCCESS;

    if ( spfic->client_ver != AF_INET && spfic->client_ver != AF_INET6 )
    {
	output.result = SPF_RESULT_UNKNOWN;
	output.reason = SPF_REASON_NONE;
	output.err = SPF_E_NOT_CONFIG;
	if ( buf ) free( buf );
	return output;
    }
    
    if ( spfic->cur_dom == NULL )
    {
	output.result = SPF_RESULT_UNKNOWN;
	output.reason = SPF_REASON_NONE;
	output.err = SPF_E_NOT_CONFIG;
	if ( buf ) free( buf );
	return output;
    }
	
    sender_dom = spfic->dp_from;
    if ( sender_dom == NULL ) sender_dom = spfic->helo_dom;

    if ( sender_dom == NULL )
    {
	output.result = SPF_RESULT_UNKNOWN;
	output.reason = SPF_REASON_NONE;
	output.err = SPF_E_NOT_CONFIG;
	if ( buf ) free( buf );
	return output;
    }


    /*
     * localhost always gets a free ride
     */

    if ( SPF_is_loopback( spfcid ) )
    {
	output.result = SPF_RESULT_PASS;
	output.reason = SPF_REASON_LOCALHOST;
	output.err = SPF_E_SUCCESS;
	if ( buf ) free( buf );
	return output;
    }
    

    /*
     * Do some start up stuff if we haven't recursed yet
     */

    local_policy = NULL;

    if ( use_local_policy )
    {
	/*
	 * find the location for the whitelist execution
	 *
	 * Philip Gladstone says:
	 *
	 * I think that the localpolicy should only be inserted if the
	 * final mechanism is '-all', and it should be inserted after
	 * the last mechanism which is not '-'.
	 *
	 * Thus for the case of 'v=spf1 +a +mx -all', this would be
	 * interpreted as 'v=spf1 +a +mx +localpolicy -all'. Whereas
	 * 'v=spf1 -all' would remain the same (no non-'-'
	 * mechanism). 'v=spf1 +a +mx -exists:%stuff -all' would
	 * become 'v=spf1 +a +mx +localpolicy -exists:%stuff -all'.
	 */
	
	if ( spfic->local_policy.spfid )
	{
	    mech = spfi->mech_first;

	    found_all = FALSE;
	    for( m = 0; m < spfi->header.num_mech; m++ )
	    {
		if ( mech->mech_type == MECH_ALL
		     && mech->prefix_type == PREFIX_FAIL )
		    found_all = TRUE;
	    
		if ( mech->prefix_type != PREFIX_FAIL )
		    local_policy = mech;

		mech = SPF_next_mech( mech );
	    }
	
	    if ( !found_all )
		local_policy = NULL;
	}
	
    }
    

    /*
     * evaluate the mechanisms
     */

    mech = spfi->mech_first;
    for( m = 0; m < spfi->header.num_mech; m++ )
    {
	if ( *num_dns_mech > spfic->max_dns_lookup
	     || *num_dns_mech > SPF_MAX_DNS_LOOKUP )
	{
	    output.result = SPF_RESULT_UNKNOWN;
	    output.reason = SPF_REASON_NONE;
	    output.err = SPF_E_BIG_DNS;
	    if ( buf ) free( buf );
	    return output;
	}
		
	switch( mech->mech_type )
	{
	case MECH_A:
	    ++*num_dns_mech;

	    data = SPF_mech_data( mech );
	    if ( data->dc.parm_type == PARM_CIDR )
		data = SPF_next_data( data );
	    
	    if ( data == SPF_mech_end_data( mech ) )
		lookup = SPF_get_cur_dom( spfcid );
	    else
	    {
		err = SPF_expand( spfcid, spfdcid,
				  data, mech->parm_len,
				  &buf, &buf_len );

		if ( err == SPF_E_NO_MEMORY )
		{
		    output.result = SPF_RESULT_ERROR;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		else if ( err )
		{
		    output.result = SPF_RESULT_UNKNOWN;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		lookup = buf;
	    }
	    
	    if ( spfic->client_ver == AF_INET )
		fetch_ns_type = ns_t_a;
	    else
		fetch_ns_type = ns_t_a6;
	    
	    rr_a = SPF_dns_lookup( spfdcid, lookup, fetch_ns_type, TRUE );
	    if ( rr_a == NULL )
		SPF_error( "SPF_dns_lookup returned null" );
    
	    if ( spfic->debug )
		printf( "found %d A records for %s\n",
			rr_a->num_rr, lookup );
	    
	    for ( i = 0; i < rr_a->num_rr; i++ )
	    {
		if ( rr_a->rr_type != fetch_ns_type )
		    continue;

		if ( SPF_ip_match( spfcid, mech, rr_a->rr[i].a ) )
		{
		    output.result = mech->prefix_type;
		    output.reason = SPF_REASON_MECH;
		    output.err = SPF_E_SUCCESS;
		    if ( buf ) free( buf );
		    return output;
		}
	    }
	    break;
	    
	case MECH_MX:
	    ++*num_dns_mech;

	    data = SPF_mech_data( mech );
	    if ( data->dc.parm_type == PARM_CIDR )
		data = SPF_next_data( data );
	    
	    if ( data == SPF_mech_end_data( mech ) )
		lookup = SPF_get_cur_dom( spfcid );
	    else
	    {
		err = SPF_expand( spfcid, spfdcid,
				  data, mech->parm_len,
				  &buf, &buf_len );

		if ( err == SPF_E_NO_MEMORY )
		{
		    output.result = SPF_RESULT_ERROR;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		else if ( err )
		{
		    output.result = SPF_RESULT_UNKNOWN;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		lookup = buf;
	    }
	    
	    rr_mx = SPF_dns_dup_rr( SPF_dns_lookup( spfdcid, lookup, ns_t_mx, TRUE ) );
	    
	    if ( rr_mx == NULL )
		SPF_error( "SPF_dns_lookup returned null" );
    
	    if ( spfic->debug )
		printf( "found %d MX records for %s\n",
			rr_mx->num_rr, lookup );
	    
	    for ( j = 0; j < rr_mx->num_rr; j++ )
	    {
		if ( rr_mx->rr_type != ns_t_mx )
		    continue;

		if ( spfic->client_ver == AF_INET )
		    fetch_ns_type = ns_t_a;
		else
		    fetch_ns_type = ns_t_a6;
	    
		rr_a = SPF_dns_lookup( spfdcid, rr_mx->rr[j].mx,
				       fetch_ns_type, TRUE );
		if ( rr_a == NULL )
		    SPF_error( "SPF_dns_lookup returned null" );
    
		if ( spfic->debug )
		    printf( "%d: found %d A records for %s\n",
			    j, rr_a->num_rr, rr_mx->rr[j].mx );
	    
		for ( i = 0; i < rr_a->num_rr; i++ )
		{
		    if ( rr_a->rr_type != fetch_ns_type )
			continue;

		    if ( SPF_ip_match( spfcid, mech, rr_a->rr[i].a ) )
		    {
			output.result = mech->prefix_type;
			output.reason = SPF_REASON_MECH;
			output.err = SPF_E_SUCCESS;
			if ( buf ) free( buf );
			SPF_dns_destroy_rr( rr_mx );
			return output;
		    }
		}
	    }

	    SPF_dns_destroy_rr( rr_mx );
	    break;
	    
	case MECH_PTR:
	    ++*num_dns_mech;

	    if ( mech->parm_len == 0 )
		sd = sender_dom;
	    else
	    {
		err = SPF_expand( spfcid, spfdcid,
				  SPF_mech_data( mech ), mech->parm_len,
				  &buf, &buf_len );

		if ( err == SPF_E_NO_MEMORY )
		{
		    output.result = SPF_RESULT_ERROR;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		else if ( err )
		{
		    output.result = SPF_RESULT_UNKNOWN;
		    output.reason = SPF_REASON_NONE;
		    output.err = err;
		    if ( buf ) free( buf );
		    return output;
		}
		sd = buf;
	    }
	    
	    
	    if ( spfic->client_ver == AF_INET )
	    {
		rr_ptr = SPF_dns_dup_rr( SPF_dns_rlookup( spfdcid, spfic->ipv4, ns_t_ptr, TRUE ) );
		if ( rr_ptr == NULL )
		    SPF_error( "SPF_dns_rlookup return NULL" );
    
		if ( spfic->debug )
		{
		    char	ip4_buf[ INET_ADDRSTRLEN ];
		    
		    const char	*p_err;
		    p_err = inet_ntop( AF_INET, &spfic->ipv4.s_addr,
				       ip4_buf, sizeof( ip4_buf ) );
		    if ( p_err == NULL )
			SPF_snprintf( ip4_buf, sizeof( ip4_buf ), "ip-error" );
		    
		    printf( "found %d PTR records for %s\n",
			    rr_ptr->num_rr, ip4_buf );
		}
	    
		for( i = 0; i < rr_ptr->num_rr; i++ )
		{
		    rr_a = SPF_dns_lookup( spfdcid, rr_ptr->rr[i].ptr, ns_t_a, TRUE );
		    if ( rr_a == NULL )
			SPF_error( "SPF_dns_lookup return NULL" );

		    if ( spfic->debug )
			printf( "%d:  found %d A records for %s\n",
				i, rr_a->num_rr, rr_ptr->rr[i].ptr );
	    
		    for( j = 0; j < rr_a->num_rr; j++ )
		    {
			if ( spfic->debug )
			{
			    char	ip4_buf[ INET_ADDRSTRLEN ];
		    
			    const char	*p_err;
			    p_err = inet_ntop( AF_INET, &rr_a->rr[j].a.s_addr,
					       ip4_buf, sizeof( ip4_buf ) );
			    if ( p_err == NULL )
				SPF_snprintf( ip4_buf, sizeof( ip4_buf ), "ip-error" );
		    
			    printf( "%d: %d:  found %s\n",
				    i, j, ip4_buf );
			}
	    
			if ( rr_a->rr[j].a.s_addr == spfic->ipv4.s_addr )
			{

			    cd = rr_ptr->rr[i].ptr;
			    pc = cd + strlen( cd ) - 1;
			    ps = sd + strlen( sd ) - 1;

			    if ( spfic->debug)
				printf( "%s == %s\n", sd, cd );
				
			    while ( pc != cd
				    && ps != sd
				    && *pc-- == *ps-- )
				;

			    if ( spfic->debug)
				printf( "%s == %s\n", ps, pc );
				
			    if ( (ps == sd && pc == cd)
				 || ( ps == sd && *(pc-1) == '.' )
				)
			    {
				output.result = mech->prefix_type;
				output.reason = SPF_REASON_MECH;
				output.err = SPF_E_SUCCESS;
				if ( buf ) free( buf );
				SPF_dns_destroy_rr( rr_ptr );
				return output;
			    }
			}
		    }
		}
		SPF_dns_destroy_rr( rr_ptr );
	    }
	    
	    else if ( spfic->client_ver == AF_INET6 )
	    {
		rr_ptr = SPF_dns_dup_rr( SPF_dns_rlookup6( spfdcid, spfic->ipv6, ns_t_ptr, TRUE ) );

		if ( rr_ptr == NULL )
		    SPF_error( "SPF_dns_rlookup return NULL" );
    
		for( i = 0; i < rr_ptr->num_rr; i++ )
		{
		    rr_a6 = SPF_dns_lookup( spfdcid, rr_ptr->rr[i].ptr, ns_t_a6, TRUE );
		    if ( rr_a6 == NULL )
			SPF_error( "SPF_dns_lookup return NULL" );

		    for( j = 0; j < rr_a6->num_rr; j++ )
		    {
			if ( memcmp( rr_a6->rr[j].a6.in6_u.u6_addr8,
				     spfic->ipv6.in6_u.u6_addr8,
				     sizeof( spfic->ipv6.in6_u.u6_addr8 ) ) == 0 )
			{
			    cd = rr_ptr->rr[i].ptr;

			    pc = cd + strlen( cd ) - 1;
			    ps = sd + strlen( sd ) - 1;

			    while ( pc != cd
				    && ps != sd
				    && *pc-- == *ps-- )
				;

			    if ( ps == sd
				 && ( pc == cd || *pc == '.' )
				)
			    {
				output.result = mech->prefix_type;
				output.reason = SPF_REASON_MECH;
				output.err = SPF_E_SUCCESS;
				if ( buf ) free( buf );
				SPF_dns_destroy_rr( rr_ptr );
				return output;
			    }
			}
		    }
		}
		SPF_dns_destroy_rr( rr_ptr );
	    }

	    break;
	    
	case MECH_INCLUDE:
	    ++*num_dns_mech;

	    err = SPF_expand( spfcid, spfdcid,
			      SPF_mech_data( mech ), mech->parm_len,
			      &buf, &buf_len );

	    if ( err == SPF_E_NO_MEMORY )
	    {
		output.result = SPF_RESULT_ERROR;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    else if ( err )
	    {
		output.result = SPF_RESULT_UNKNOWN;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    lookup = buf;
	    
	    /*
	     * get the (compiled) SPF record
	     */
    
	    err = SPF_get_spf( spfcid, spfdcid, lookup, &c_results );

	    if ( spfic->debug > 0 )
		printf( "include:  getting SPF record:  %s\n",
			SPF_strerror( err ) );
		

	    if ( err == SPF_E_SUCCESS )
	    {
		/*
		 * find out whether this configuration passes
		 */
		
		save_cur_dom = strdup( SPF_get_cur_dom( spfcid ) );
		SPF_set_cur_dom( spfcid, lookup );
		inc_out = SPF_eval_id( spfcid, c_results.spfid, spfdcid,
				       num_dns_mech, FALSE );
		SPF_set_cur_dom( spfcid, save_cur_dom );
		free( save_cur_dom );
		SPF_free_c_results( &c_results );

		if ( spfic->debug > 0 )
		    printf( "include:  executed SPF record:  %s  result: %s  reason: %s\n",
			    SPF_strerror( inc_out.err ),
			    SPF_strresult( inc_out.result ),
			    SPF_strreason( inc_out.reason ) );
		
		switch ( inc_out.result )
		{
		case SPF_RESULT_PASS:
		    output.result = mech->prefix_type;
		    output.reason = SPF_REASON_MECH;
		    output.err = inc_out.err;
		    SPF_free_output( &inc_out );
		    if ( buf ) free( buf );
		    return output;
		    break;
		    
		case SPF_RESULT_ERROR:
		    output.result = inc_out.result;
		    output.reason = SPF_REASON_MECH;
		    output.err = inc_out.err;
		    SPF_free_output( &inc_out );
		    if ( buf ) free( buf );
		    return output;
		    break;

		case SPF_RESULT_NEUTRAL:
		case SPF_RESULT_SOFTFAIL:
		case SPF_RESULT_FAIL:
		    SPF_free_output( &inc_out );
		    break;

		case SPF_RESULT_NONE:
		case SPF_RESULT_UNKNOWN:
		default:
		    output.result = SPF_RESULT_UNKNOWN;
		    output.reason = SPF_REASON_MECH;
		    output.err = inc_out.err;
		    SPF_free_output( &inc_out );
		    if ( buf ) free( buf );
		    return output;
		    break;
		}
	    }
	    else if ( err == SPF_E_DNS_ERROR )
	    {
		output.result = SPF_RESULT_ERROR;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    else
	    {
		output.result = SPF_RESULT_UNKNOWN;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    

	    
	    break;
	    
	case MECH_IP4:
	    if ( SPF_ip_match( spfcid, mech, *SPF_mech_ip4_data( mech ) ) )
	    {
		output.result = mech->prefix_type;
		output.reason = SPF_REASON_MECH;
		output.err = SPF_E_SUCCESS;
		if ( buf ) free( buf );
		return output;
	    }
	    break;
	    
	case MECH_IP6:
	    if ( SPF_ip_match6( spfcid, mech, *SPF_mech_ip6_data( mech ) ) )
	    {
		output.result = mech->prefix_type;
		output.reason = SPF_REASON_MECH;
		output.err = SPF_E_SUCCESS;
		if ( buf ) free( buf );
		return output;
	    }
	    break;
	    
	case MECH_EXISTS:
	    ++*num_dns_mech;

	    err = SPF_expand( spfcid, spfdcid,
			      SPF_mech_data( mech ), mech->parm_len,
			      &buf, &buf_len );

	    if ( err == SPF_E_NO_MEMORY )
	    {
		output.result = SPF_RESULT_ERROR;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    else if ( err )
	    {
		output.result = SPF_RESULT_UNKNOWN;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    lookup = buf;
	    
	    rr_a = SPF_dns_lookup( spfdcid, lookup, ns_t_a, FALSE );
	    if ( rr_a == NULL )
		SPF_error( "SPF_dns_lookup returned null" );
    
	    if ( spfic->debug )
		printf( "found %d A records for %s\n",
			rr_a->num_rr, lookup );
	    
	    if ( rr_a->num_rr > 0 )
	    {
		output.result = mech->prefix_type;
		output.reason = SPF_REASON_MECH;
		output.err = SPF_E_SUCCESS;
		if ( buf ) free( buf );
		return output;
	    }
	    
	    break;
	    
	case MECH_ALL:
	    output.result = mech->prefix_type;
	    output.reason = SPF_REASON_MECH;
	    output.err = SPF_E_SUCCESS;
	    if ( buf ) free( buf );
	    return output;
	    break;
	    
	case MECH_REDIRECT:
	    ++*num_dns_mech;

	    err = SPF_expand( spfcid, spfdcid,
			      SPF_mech_data( mech ), mech->parm_len,
			      &buf, &buf_len );

	    if ( err == SPF_E_NO_MEMORY )
	    {
		output.result = SPF_RESULT_ERROR;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    else if ( err )
	    {
		output.result = SPF_RESULT_UNKNOWN;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    lookup = buf;
	    
	    /*
	     * get the (compiled) SPF record
	     */
    
	    err = SPF_get_spf( spfcid, spfdcid, lookup, &c_results );

	    if ( spfic->debug > 0 )
		printf( "redirect:  getting SPF record:  %s\n",
			SPF_strerror( err ) );
		

	    if ( err == SPF_E_SUCCESS )
	    {
		/*
		 * find out whether this configuration passes
		 */
		
		SPF_set_cur_dom( spfcid, lookup );
		inc_out = SPF_eval_id( spfcid, c_results.spfid, spfdcid,
				       num_dns_mech, TRUE );
		SPF_free_c_results( &c_results );

		if ( spfic->debug > 0 )
		    printf( "redirect:  executed SPF record:  %s  result: %s  reason: %s\n",
			    SPF_strerror( inc_out.err ),
			    SPF_strresult( inc_out.result ),
			    SPF_strreason( inc_out.reason ) );
		
		output.result = inc_out.result;
		output.reason = SPF_REASON_MECH;
		output.err = inc_out.err;
		SPF_free_output( &inc_out );
		if ( buf ) free( buf );
		return output;
	    }
	    else if ( err == SPF_E_DNS_ERROR )
	    {
		output.result = SPF_RESULT_ERROR;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    else
	    {
		output.result = SPF_RESULT_UNKNOWN;
		output.reason = SPF_REASON_NONE;
		output.err = err;
		if ( buf ) free( buf );
		return output;
	    }
	    

	    
	    break;

	default:
	    output.result = SPF_RESULT_UNKNOWN;
	    output.reason = SPF_REASON_NONE;
	    output.err = SPF_E_UNKNOWN_MECH;
	    if ( buf ) free( buf );
	    return output;
	    break;
	}
	    

	/*
	 * execute the local policy
	 */

	if ( mech == local_policy )
	{
	    inc_out = SPF_eval_id( spfcid, spfic->local_policy.spfid,
				   spfdcid, NULL, FALSE );

	    if ( spfic->debug > 0 )
		printf( "local_policy:  executed SPF record:  %s  result: %s  reason: %s\n",
			    SPF_strerror( inc_out.err ),
			    SPF_strresult( inc_out.result ),
			    SPF_strreason( inc_out.reason ) );
		
	    if ( inc_out.reason != SPF_REASON_DEFAULT )
	    {
		output.result = inc_out.result;
		output.reason = SPF_REASON_LOCAL_POLICY;
		output.err = inc_out.err;
		SPF_free_output( &inc_out );
		if ( buf ) free( buf );
		return output;
	    }
	    SPF_free_output( &inc_out );

	}
	
	mech = SPF_next_mech( mech );
    }

    /* falling off the end is the same as ?all */
    output.result = SPF_RESULT_NEUTRAL;
    output.reason = SPF_REASON_DEFAULT;
    output.err = SPF_E_SUCCESS;
    if ( buf ) free( buf );
    return output;
}


